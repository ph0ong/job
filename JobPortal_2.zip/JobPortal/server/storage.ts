import { type Company, type Job, type Application, type InsertCompany, type InsertJob, type InsertApplication, type JobWithCompany, type User, type UpsertUser } from "@shared/schema";
import { users, companies, jobs, applications } from "@shared/schema";
import { db } from "./db";
import { eq, and, ilike } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Companies
  getCompanies(): Promise<Company[]>;
  getCompany(id: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;

  // Jobs
  getJobs(filters?: { type?: string; category?: string; location?: string; search?: string }): Promise<JobWithCompany[]>;
  getJob(id: string): Promise<JobWithCompany | undefined>;
  getJobsByCompany(companyId: string): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;

  // Applications
  getApplications(): Promise<Application[]>;
  getApplicationsByJob(jobId: string): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
}

export class DatabaseStorage implements IStorage {
  private seedData: {
    companies: Company[];
    jobs: Job[];
  };

  constructor() {
    this.seedData = this.initializeSeedData();
  }

  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      return undefined;
    }
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    try {
      const [user] = await db
        .insert(users)
        .values(userData)
        .onConflictDoUpdate({
          target: users.id,
          set: {
            ...userData,
            updatedAt: new Date(),
          },
        })
        .returning();
      return user;
    } catch (error) {
      // Fallback for development
      return {
        id: userData.id || randomUUID(),
        email: userData.email || null,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || null,
        createdAt: new Date(),
        updatedAt: new Date()
      };
    }
  }

  async getCompanies(): Promise<Company[]> {
    try {
      const result = await db.select().from(companies);
      return result.length > 0 ? result : this.seedData.companies;
    } catch (error) {
      return this.seedData.companies;
    }
  }

  async getCompany(id: string): Promise<Company | undefined> {
    try {
      const [company] = await db.select().from(companies).where(eq(companies.id, id));
      return company || this.seedData.companies.find(c => c.id === id);
    } catch (error) {
      return this.seedData.companies.find(c => c.id === id);
    }
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    try {
      const [newCompany] = await db.insert(companies).values(company).returning();
      return newCompany;
    } catch (error) {
      const id = randomUUID();
      return { 
        ...company, 
        id, 
        createdAt: new Date(),
        logo: company.logo || null,
        website: company.website || null
      };
    }
  }

  async getJobs(filters?: { type?: string; category?: string; location?: string; search?: string }): Promise<JobWithCompany[]> {
    try {
      const result = await db.select()
        .from(jobs)
        .leftJoin(companies, eq(jobs.companyId, companies.id))
        .where(eq(jobs.isActive, true));

      let jobsWithCompany = result.map(row => ({
        ...row.jobs,
        company: row.companies!
      }));

      if (jobsWithCompany.length === 0) {
        jobsWithCompany = this.getSeedJobsWithCompany();
      }

      if (filters) {
        if (filters.type) {
          jobsWithCompany = jobsWithCompany.filter(job => job.type === filters.type);
        }
        if (filters.category) {
          jobsWithCompany = jobsWithCompany.filter(job => job.category === filters.category);
        }
        if (filters.location && filters.location !== "all") {
          jobsWithCompany = jobsWithCompany.filter(job => job.location.toLowerCase().includes(filters.location!.toLowerCase()));
        }
        if (filters.search) {
          const searchTerm = filters.search.toLowerCase();
          jobsWithCompany = jobsWithCompany.filter(job => 
            job.title.toLowerCase().includes(searchTerm) ||
            job.description.toLowerCase().includes(searchTerm) ||
            job.skills.some(skill => skill.toLowerCase().includes(searchTerm))
          );
        }
      }

      return jobsWithCompany.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    } catch (error) {
      return this.getSeedJobsWithCompany(filters);
    }
  }

  async getJob(id: string): Promise<JobWithCompany | undefined> {
    try {
      const [result] = await db.select()
        .from(jobs)
        .leftJoin(companies, eq(jobs.companyId, companies.id))
        .where(eq(jobs.id, id));
      
      if (result) {
        return {
          ...result.jobs,
          company: result.companies!
        };
      }

      return this.getSeedJobsWithCompany().find(j => j.id === id);
    } catch (error) {
      return this.getSeedJobsWithCompany().find(j => j.id === id);
    }
  }

  async getJobsByCompany(companyId: string): Promise<Job[]> {
    try {
      const result = await db.select().from(jobs).where(and(eq(jobs.companyId, companyId), eq(jobs.isActive, true)));
      return result.length > 0 ? result : this.seedData.jobs.filter(job => job.companyId === companyId && job.isActive);
    } catch (error) {
      return this.seedData.jobs.filter(job => job.companyId === companyId && job.isActive);
    }
  }

  async createJob(job: InsertJob): Promise<Job> {
    try {
      const [newJob] = await db.insert(jobs).values(job).returning();
      return newJob;
    } catch (error) {
      const id = randomUUID();
      return { 
        ...job, 
        id, 
        createdAt: new Date(),
        salary: job.salary || null,
        duration: job.duration || null,
        isActive: job.isActive ?? true,
        skills: job.skills || []
      };
    }
  }

  async getApplications(): Promise<Application[]> {
    try {
      return await db.select().from(applications);
    } catch (error) {
      return [];
    }
  }

  async getApplicationsByJob(jobId: string): Promise<Application[]> {
    try {
      return await db.select().from(applications).where(eq(applications.jobId, jobId));
    } catch (error) {
      return [];
    }
  }

  async createApplication(application: InsertApplication): Promise<Application> {
    try {
      const [newApplication] = await db.insert(applications).values(application).returning();
      return newApplication;
    } catch (error) {
      const id = randomUUID();
      return { 
        ...application, 
        id, 
        appliedAt: new Date(),
        status: application.status || "pending",
        applicantPhone: application.applicantPhone || null,
        coverLetter: application.coverLetter || null,
        resumeUrl: application.resumeUrl || null
      };
    }
  }

  private initializeSeedData() {
    const companies: Company[] = [
      {
        id: "a6767221-c74f-465f-8e38-1f2993acc9b7",
        name: "TechCorp Vietnam",
        description: "Leading technology company offering innovative internship programs and career development opportunities for students.",
        logo: "https://images.unsplash.com/photo-1549924231-f129b911e442?w=100&h=100&fit=crop&crop=center",
        website: "https://techcorp.vn",
        industry: "Technology",
        size: "500+ employees",
        location: "Ho Chi Minh City",
        createdAt: new Date(),
      },
      {
        id: "b7878332-d85f-576g-9f49-2g3004bdd0c8",
        name: "CreativeHub Studio",
        description: "Award-winning creative agency specializing in branding and digital experiences for innovative brands.",
        logo: "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=100&h=100&fit=crop&crop=center",
        website: "https://creativehub.vn",
        industry: "Design & Creative",
        size: "150+ employees",
        location: "Ha Noi",
        createdAt: new Date(),
      },
      {
        id: "c8989443-e96g-687h-ag5a-3h4115cee1d9",
        name: "Global Marketing Co.",
        description: "International marketing firm providing comprehensive training and mentorship programs for ambitious students.",
        logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=100&fit=crop&crop=center",
        website: "https://globalmarketing.vn",
        industry: "Marketing",
        size: "800+ employees",
        location: "Ho Chi Minh City",
        createdAt: new Date(),
      },
      {
        id: "d9a9a554-fa7h-798i-bh6b-4i5226dff2ea",
        name: "InnovateTech Solutions",
        description: "Cutting-edge software development company focused on AI and machine learning solutions.",
        logo: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=100&h=100&fit=crop&crop=center",
        website: "https://innovatetech.vn",
        industry: "Technology",
        size: "300+ employees",
        location: "Da Nang",
        createdAt: new Date(),
      }
    ];

    const jobs: Job[] = [
      {
        id: "21f15b88-a653-4d02-bf2f-5ac61ae40809",
        title: "Marketing Intern",
        description: "Join our dynamic marketing team to learn about digital marketing strategies, social media management, and campaign optimization. You'll work closely with experienced marketers on real projects that impact our business.",
        requirements: "Currently pursuing a degree in Marketing, Business, or related field. Strong communication skills, creativity, and enthusiasm for digital marketing. Basic knowledge of social media platforms and analytics tools is a plus.",
        benefits: "Mentorship from industry experts, hands-on experience with real campaigns, flexible working hours, competitive stipend, networking opportunities, and potential for full-time offer.",
        companyId: "a6767221-c74f-465f-8e38-1f2993acc9b7",
        location: "Ho Chi Minh City",
        type: "internship",
        category: "Marketing",
        salary: "5-7 million VND",
        duration: "3 months",
        isActive: true,
        skills: ["Social Media", "Content Creation", "Analytics", "Communication"],
        createdAt: new Date(),
      },
      {
        id: "32g26c99-b764-5e13-cg3g-6bd72bf51910",
        title: "Frontend Developer",
        description: "Develop modern web applications using React, TypeScript, and cutting-edge frontend technologies. Work in an Agile environment with a collaborative team of designers and backend developers.",
        requirements: "Strong knowledge of React, JavaScript/TypeScript, HTML5, CSS3. Experience with modern build tools and version control (Git). Portfolio showcasing previous projects. Understanding of responsive design principles.",
        benefits: "Flexible remote work options, modern tech stack, professional development budget, health insurance, team building activities, and career advancement opportunities.",
        companyId: "a6767221-c74f-465f-8e38-1f2993acc9b7",
        location: "Remote",
        type: "part-time",
        category: "IT",
        salary: "15-20 million VND",
        duration: null,
        isActive: true,
        skills: ["React", "TypeScript", "JavaScript", "HTML/CSS", "Git"],
        createdAt: new Date(),
      },
      {
        id: "43h37daa-c875-6f24-dh4h-7ce83cg62a21",
        title: "Graphic Designer",
        description: "Create stunning visual designs for digital and print media. Work on branding projects, social media graphics, and marketing materials for diverse clients across various industries.",
        requirements: "Proficiency in Adobe Creative Suite (Photoshop, Illustrator, InDesign). Strong portfolio demonstrating creative skills. Understanding of design principles, typography, and color theory. Fresh graduates welcome.",
        benefits: "Creative freedom, exposure to diverse projects, mentorship from senior designers, flexible schedule, competitive salary, and opportunities for professional growth.",
        companyId: "b7878332-d85f-576g-9f49-2g3004bdd0c8",
        location: "Ha Noi",
        type: "full-time",
        category: "Design",
        salary: "12-18 million VND",
        duration: null,
        isActive: true,
        skills: ["Adobe Creative Suite", "Typography", "Branding", "Layout Design"],
        createdAt: new Date(),
      },
      {
        id: "54i48ebb-d986-7g35-ei5i-8df94dh73b32",
        title: "Data Analyst Intern",
        description: "Analyze market trends, consumer behavior, and campaign performance data. Create insightful reports and visualizations to support strategic business decisions.",
        requirements: "Strong analytical and mathematical skills. Experience with Excel, SQL, or Python is preferred. Currently studying Business, Statistics, Economics, or related field. Detail-oriented with good communication skills.",
        benefits: "Hands-on experience with real data, training in advanced analytics tools, mentorship from data experts, internship certificate, and potential for full-time position.",
        companyId: "c8989443-e96g-687h-ag5a-3h4115cee1d9",
        location: "Ho Chi Minh City",
        type: "internship",
        category: "Analytics",
        salary: "6-8 million VND",
        duration: "4 months",
        isActive: true,
        skills: ["Excel", "SQL", "Data Analysis", "Statistics", "Reporting"],
        createdAt: new Date(),
      }
    ];

    return { companies, jobs };
  }

  private getSeedJobsWithCompany(filters?: { type?: string; category?: string; location?: string; search?: string }): JobWithCompany[] {
    let jobsWithCompany: JobWithCompany[] = this.seedData.jobs
      .filter(job => job.isActive)
      .map(job => ({
        ...job,
        company: this.seedData.companies.find(c => c.id === job.companyId)!
      }));

    if (filters) {
      if (filters.type) {
        jobsWithCompany = jobsWithCompany.filter(job => job.type === filters.type);
      }
      if (filters.category) {
        jobsWithCompany = jobsWithCompany.filter(job => job.category === filters.category);
      }
      if (filters.location && filters.location !== "all") {
        jobsWithCompany = jobsWithCompany.filter(job => job.location.toLowerCase().includes(filters.location!.toLowerCase()));
      }
      if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        jobsWithCompany = jobsWithCompany.filter(job => 
          job.title.toLowerCase().includes(searchTerm) ||
          job.description.toLowerCase().includes(searchTerm) ||
          job.skills.some(skill => skill.toLowerCase().includes(searchTerm))
        );
      }
    }

    return jobsWithCompany.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }
}

export const storage = new DatabaseStorage();