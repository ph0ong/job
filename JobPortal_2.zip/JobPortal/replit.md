# Overview

This is a Vietnamese job board application called "StudentJobs" designed specifically for students seeking internships, part-time, and full-time positions. The platform connects students with companies offering career opportunities, featuring comprehensive job listings, company profiles, and an application system. The application uses a modern full-stack architecture with TypeScript, React, Express, and PostgreSQL.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with pages for home, jobs, job details, companies, and company details
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Forms**: React Hook Form with Zod for validation and type safety

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with endpoints for jobs, companies, and applications
- **Error Handling**: Centralized error middleware with structured error responses
- **Logging**: Custom request logging middleware for API monitoring

## Data Storage
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Shared schema definitions using Drizzle with Zod validation
- **Migrations**: Drizzle Kit for database migrations and schema management

## Development Setup
- **Monorepo Structure**: Organized with `client/`, `server/`, and `shared/` directories
- **Hot Reload**: Vite dev server with HMR for frontend, tsx for backend development
- **Build Process**: Vite for frontend bundling, esbuild for backend compilation
- **Path Aliases**: Configured for clean imports (`@/`, `@shared/`)

## Key Features
- **Job Management**: Browse, filter, and search jobs by type, category, location, and keywords
- **Company Profiles**: Comprehensive company information with job listings
- **Application System**: Form-based job applications with validation
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Vietnamese Localization**: Content and UI text in Vietnamese language

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL database for production
- **Database URL**: Environment variable `DATABASE_URL` required for connection

## UI Components
- **Radix UI**: Comprehensive primitive components for accessibility and interaction
- **Lucide Icons**: Icon library for consistent iconography
- **React Icons**: Additional icon sets including social media icons

## Development Tools
- **Replit Integration**: Custom Vite plugins for Replit environment
- **TypeScript**: Strict type checking with shared types across frontend and backend
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer

## Runtime Dependencies
- **Express**: Web framework with middleware for JSON parsing and CORS
- **TanStack Query**: Data fetching and caching library
- **Date-fns**: Date manipulation and formatting utilities
- **Class Variance Authority**: Utility for managing component variants