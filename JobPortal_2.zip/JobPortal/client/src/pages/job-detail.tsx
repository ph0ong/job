import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ArrowLeft, MapPin, Clock, DollarSign, Calendar, Building, Users, Send, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { JobWithCompany } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertApplicationSchema } from "@shared/schema";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const applicationFormSchema = insertApplicationSchema.extend({
  applicantEmail: z.string().email("Email không hợp lệ"),
  applicantName: z.string().min(2, "Tên phải có ít nhất 2 ký tự"),
  applicantPhone: z.string().optional(),
  coverLetter: z.string().min(10, "Thư xin việc phải có ít nhất 10 ký tự"),
});

type ApplicationFormData = z.infer<typeof applicationFormSchema>;

export default function JobDetail() {
  const params = useParams();
  const jobId = params.id as string;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isApplicationOpen, setIsApplicationOpen] = useState(false);

  const { data: job, isLoading } = useQuery<JobWithCompany>({
    queryKey: ["/api/jobs", jobId],
    enabled: !!jobId,
  });

  const form = useForm<ApplicationFormData>({
    resolver: zodResolver(applicationFormSchema),
    defaultValues: {
      jobId,
      applicantName: "",
      applicantEmail: "",
      applicantPhone: "",
      coverLetter: "",
      resumeUrl: "",
    },
  });

  const applicationMutation = useMutation({
    mutationFn: (data: ApplicationFormData) => apiRequest("POST", "/api/applications", data),
    onSuccess: () => {
      toast({
        title: "Thành công!",
        description: "Đơn ứng tuyển của bạn đã được gửi thành công!",
      });
      setIsApplicationOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Có lỗi xảy ra khi gửi đơn ứng tuyển. Vui lòng thử lại.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ApplicationFormData) => {
    applicationMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="h-12 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Không tìm thấy việc làm</h1>
              <p className="text-gray-600 mb-4">Công việc này có thể đã bị xóa hoặc không tồn tại.</p>
              <Link href="/jobs">
                <Button>Quay lại danh sách việc làm</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "internship":
        return "bg-green-100 text-green-800";
      case "part-time":
        return "bg-blue-100 text-blue-800";
      case "full-time":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "internship":
        return "Thực tập";
      case "part-time":
        return "Part-time";
      case "full-time":
        return "Full-time";
      default:
        return type;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back button */}
        <Link href="/jobs">
          <Button variant="ghost" className="mb-6" data-testid="button-back-to-jobs">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Quay lại danh sách việc làm
          </Button>
        </Link>

        {/* Job Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mr-6">
                  <img
                    src={job.company.logo || "https://images.unsplash.com/photo-1549924231-f129b911e442?w=100&h=100&fit=crop&crop=center"}
                    alt={job.company.name}
                    className="w-12 h-12 rounded object-cover"
                  />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-job-title">
                    {job.title}
                  </h1>
                  <Link href={`/companies/${job.company.id}`}>
                    <Button variant="link" className="text-xl text-primary p-0 h-auto" data-testid="link-company">
                      {job.company.name}
                    </Button>
                  </Link>
                </div>
              </div>
              <Badge className={`${getTypeColor(job.type)} text-sm px-3 py-1`}>
                {getTypeLabel(job.type)}
              </Badge>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="flex items-center text-gray-600">
                <MapPin className="h-5 w-5 mr-2" />
                <span data-testid="text-job-location">{job.location}</span>
              </div>
              {job.salary && (
                <div className="flex items-center text-gray-600">
                  <DollarSign className="h-5 w-5 mr-2" />
                  <span data-testid="text-job-salary">{job.salary}</span>
                </div>
              )}
              {job.duration && (
                <div className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 mr-2" />
                  <span data-testid="text-job-duration">{job.duration}</span>
                </div>
              )}
              <div className="flex items-center text-gray-600">
                <Calendar className="h-5 w-5 mr-2" />
                <span data-testid="text-job-posted">
                  {new Date(job.createdAt!).toLocaleDateString('vi-VN')}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {job.skills.map((skill) => (
                  <Badge key={skill} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>

              <Dialog open={isApplicationOpen} onOpenChange={setIsApplicationOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-white hover:bg-blue-600 px-8" data-testid="button-apply">
                    <Send className="h-4 w-4 mr-2" />
                    Ứng tuyển ngay
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Ứng tuyển: {job.title}</DialogTitle>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="applicantName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Họ và tên *</FormLabel>
                            <FormControl>
                              <Input placeholder="Nguyễn Văn A" {...field} data-testid="input-applicant-name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="applicantEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email *</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="your.email@gmail.com" {...field} data-testid="input-applicant-email" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="applicantPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Số điện thoại</FormLabel>
                            <FormControl>
                              <Input placeholder="0901234567" {...field} data-testid="input-applicant-phone" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="resumeUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Link CV (Google Drive, Dropbox, etc.)</FormLabel>
                            <FormControl>
                              <Input placeholder="https://drive.google.com/..." {...field} value={field.value || ""} data-testid="input-resume-url" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="coverLetter"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Thư xin việc *</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Viết vài dòng về bản thân và lý do bạn phù hợp với vị trí này..."
                                className="min-h-[120px]"
                                {...field}
                                data-testid="textarea-cover-letter"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end space-x-4 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsApplicationOpen(false)}
                          data-testid="button-cancel-application"
                        >
                          Hủy
                        </Button>
                        <Button
                          type="submit"
                          disabled={applicationMutation.isPending}
                          className="bg-primary text-white hover:bg-blue-600"
                          data-testid="button-submit-application"
                        >
                          {applicationMutation.isPending ? "Đang gửi..." : "Gửi đơn ứng tuyển"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Job Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Mô tả công việc</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none" data-testid="text-job-description">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {job.description}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Yêu cầu ứng viên</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none" data-testid="text-job-requirements">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {job.requirements}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quyền lợi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none" data-testid="text-job-benefits">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {job.benefits}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Company Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="h-5 w-5 mr-2" />
                  Về công ty
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <img
                    src={job.company.logo || "https://images.unsplash.com/photo-1549924231-f129b911e442?w=100&h=100&fit=crop&crop=center"}
                    alt={job.company.name}
                    className="w-16 h-16 rounded-lg mx-auto mb-4 object-cover"
                  />
                  <h3 className="font-semibold text-lg" data-testid="text-company-name">
                    {job.company.name}
                  </h3>
                  <p className="text-gray-600 text-sm" data-testid="text-company-industry">
                    {job.company.industry}
                  </p>
                </div>
                <p className="text-gray-700 text-sm mb-4" data-testid="text-company-description">
                  {job.company.description}
                </p>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    <span data-testid="text-company-size">{job.company.size}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span data-testid="text-company-location">{job.company.location}</span>
                  </div>
                </div>
                <Link href={`/companies/${job.company.id}`}>
                  <Button variant="outline" className="w-full mt-4" data-testid="button-view-company">
                    Xem trang công ty
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Job Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Thông tin thêm</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Ngành nghề:</span>
                  <span className="font-medium" data-testid="text-job-category">{job.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Hình thức:</span>
                  <span className="font-medium">{getTypeLabel(job.type)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Cập nhật:</span>
                  <span className="font-medium">
                    {new Date(job.createdAt!).toLocaleDateString('vi-VN')}
                  </span>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex items-center text-green-600 text-sm">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    <span>Đang tuyển dụng</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
