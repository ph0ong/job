import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Search, Filter, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { JobWithCompany } from "@shared/schema";
import Header from "@/components/header";
import Footer from "@/components/footer";
import JobCard from "@/components/job-card";

export default function Jobs() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedType, setSelectedType] = useState(searchParams.get('type') || 'all');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'all');
  const [selectedLocation, setSelectedLocation] = useState(searchParams.get('location') || 'all');

  const queryParams = {
    search: searchQuery || undefined,
    type: selectedType === 'all' ? undefined : selectedType,
    category: selectedCategory === 'all' ? undefined : selectedCategory,
    location: selectedLocation === 'all' ? undefined : selectedLocation,
  };

  const { data: jobs = [], isLoading } = useQuery<JobWithCompany[]>({
    queryKey: ["/api/jobs", queryParams],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(queryParams).forEach(([key, value]) => {
        if (value) params.set(key, value);
      });
      const response = await fetch(`/api/jobs?${params}`);
      if (!response.ok) throw new Error('Failed to fetch jobs');
      return response.json();
    },
  });

  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1] || '');
    setSearchQuery(params.get('search') || '');
    setSelectedType(params.get('type') || 'all');
    setSelectedCategory(params.get('category') || 'all');
    setSelectedLocation(params.get('location') || 'all');
  }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The query will automatically refetch due to the dependency on state variables
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedType('all');
    setSelectedCategory('all');
    setSelectedLocation('all');
  };

  const categories = [
    'Marketing',
    'Technology',
    'Design',
    'Sales',
    'Finance',
    'Operations',
    'HR',
    'Customer Service',
  ];

  const locations = [
    'Ho Chi Minh',
    'Ha Noi',
    'Da Nang',
    'Remote',
    'Can Tho',
    'Hai Phong',
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="bg-light py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Tìm Việc Làm</h1>
            <p className="text-lg text-muted">
              Khám phá {jobs.length} cơ hội việc làm dành cho sinh viên
            </p>
          </div>

          {/* Search and Filters */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <form onSubmit={handleSearch} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        type="text"
                        placeholder="Tên công việc, kỹ năng..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                        data-testid="input-job-search"
                      />
                    </div>
                  </div>

                  <Select value={selectedType} onValueChange={setSelectedType}>
                    <SelectTrigger data-testid="select-job-type">
                      <SelectValue placeholder="Loại hình" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tất cả</SelectItem>
                      <SelectItem value="internship">Thực tập</SelectItem>
                      <SelectItem value="part-time">Part-time</SelectItem>
                      <SelectItem value="full-time">Full-time</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger data-testid="select-job-category">
                      <SelectValue placeholder="Ngành nghề" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tất cả ngành nghề</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                    <SelectTrigger data-testid="select-job-location">
                      <SelectValue placeholder="Địa điểm" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tất cả địa điểm</SelectItem>
                      {locations.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={clearFilters}
                    className="text-gray-600"
                    data-testid="button-clear-filters"
                  >
                    <Filter className="h-4 w-4 mr-2" />
                    Xóa bộ lọc
                  </Button>
                  <Button
                    type="submit"
                    className="bg-primary text-white hover:bg-blue-600"
                    data-testid="button-apply-filters"
                  >
                    Áp dụng bộ lọc
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="flex items-center justify-between mb-6">
            <p className="text-gray-600" data-testid="text-job-results">
              Hiển thị {jobs.length} kết quả
            </p>
            <Select defaultValue="newest">
              <SelectTrigger className="w-48" data-testid="select-sort">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Mới nhất</SelectItem>
                <SelectItem value="oldest">Cũ nhất</SelectItem>
                <SelectItem value="salary-high">Lương cao nhất</SelectItem>
                <SelectItem value="salary-low">Lương thấp nhất</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Job Listings */}
          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Không tìm thấy việc làm</h3>
                <p className="text-gray-600 mb-4">
                  Thử điều chỉnh bộ lọc hoặc tìm kiếm với từ khóa khác
                </p>
                <Button onClick={clearFilters} variant="outline" data-testid="button-clear-search">
                  Xóa bộ lọc
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
              {jobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          )}

          {/* Load More Button */}
          {jobs.length > 0 && jobs.length >= 10 && (
            <div className="text-center">
              <Button
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white"
                data-testid="button-load-more"
              >
                Xem thêm việc làm
              </Button>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
