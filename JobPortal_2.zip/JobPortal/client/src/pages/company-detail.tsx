import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ArrowLeft, MapPin, Users, Globe, Building, Briefcase, Calendar, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Company, Job } from "@shared/schema";
import Header from "@/components/header";
import Footer from "@/components/footer";
import JobCard from "@/components/job-card";

export default function CompanyDetail() {
  const params = useParams();
  const companyId = params.id as string;

  const { data: company, isLoading: companyLoading } = useQuery<Company>({
    queryKey: ["/api/companies", companyId],
    enabled: !!companyId,
  });

  const { data: jobs = [], isLoading: jobsLoading } = useQuery<Job[]>({
    queryKey: ["/api/companies", companyId, "jobs"],
    enabled: !!companyId,
  });

  // Transform jobs to include company data for JobCard component
  const jobsWithCompany = jobs.map(job => ({
    ...job,
    company: company!
  }));

  if (companyLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Không tìm thấy công ty</h1>
              <p className="text-gray-600 mb-4">Công ty này có thể đã bị xóa hoặc không tồn tại.</p>
              <Link href="/companies">
                <Button data-testid="button-back-to-companies">Quay lại danh sách công ty</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back button */}
        <Link href="/companies">
          <Button variant="ghost" className="mb-6" data-testid="button-back-to-companies">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Quay lại danh sách công ty
          </Button>
        </Link>

        {/* Company Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            {/* Company Hero Image */}
            <div className="relative h-48 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg mb-6 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=400"
                alt="Company office"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20"></div>
            </div>

            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center">
                <div className="w-20 h-20 bg-white rounded-lg shadow-md flex items-center justify-center mr-6 -mt-10 relative z-10">
                  <img
                    src={company.logo || "https://images.unsplash.com/photo-1549924231-f129b911e442?w=100&h=100&fit=crop&crop=center"}
                    alt={company.name}
                    className="w-16 h-16 rounded object-cover"
                  />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-company-name">
                    {company.name}
                  </h1>
                  <div className="flex items-center space-x-4 text-gray-600">
                    <div className="flex items-center">
                      <Building className="h-4 w-4 mr-1" />
                      <span data-testid="text-company-industry">{company.industry}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span data-testid="text-company-location">{company.location}</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      <span data-testid="text-company-size">{company.size}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                {company.website && (
                  <a
                    href={company.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex"
                  >
                    <Button variant="outline" data-testid="button-company-website">
                      <Globe className="h-4 w-4 mr-2" />
                      Website
                      <ExternalLink className="h-4 w-4 ml-2" />
                    </Button>
                  </a>
                )}
                <Badge className="bg-green-100 text-green-800 px-3 py-1">
                  <Briefcase className="h-3 w-3 mr-1" />
                  {jobs.length} vị trí đang tuyển
                </Badge>
              </div>
            </div>

            <p className="text-gray-700 text-lg leading-relaxed" data-testid="text-company-description">
              {company.description}
            </p>
          </CardContent>
        </Card>

        {/* Company Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Briefcase className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900" data-testid="text-active-jobs">
                {jobs.length}
              </div>
              <div className="text-sm text-gray-600">Vị trí đang tuyển</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-accent mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900" data-testid="text-company-employees">
                {company.size.split('+')[0]}+
              </div>
              <div className="text-sm text-gray-600">Nhân viên</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Building className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900" data-testid="text-company-industry-tag">
                {company.industry}
              </div>
              <div className="text-sm text-gray-600">Ngành nghề</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Calendar className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900" data-testid="text-company-founded">
                {new Date(company.createdAt!).getFullYear()}
              </div>
              <div className="text-sm text-gray-600">Thành lập</div>
            </CardContent>
          </Card>
        </div>

        {/* Available Jobs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Vị trí đang tuyển dụng</span>
              <Badge variant="secondary" data-testid="badge-job-count">
                {jobs.length} vị trí
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {jobsLoading ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : jobs.length === 0 ? (
              <div className="text-center py-12">
                <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Chưa có vị trí nào</h3>
                <p className="text-gray-600 mb-4">
                  Công ty này hiện chưa có vị trí tuyển dụng nào. Hãy theo dõi để cập nhật thông tin mới nhất.
                </p>
                <Link href="/jobs">
                  <Button variant="outline" data-testid="button-browse-other-jobs">
                    Xem việc làm khác
                  </Button>
                </Link>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                  {jobsWithCompany.map((job) => (
                    <JobCard key={job.id} job={job} />
                  ))}
                </div>
                
                {jobs.length > 4 && (
                  <div className="text-center border-t pt-6">
                    <Link href={`/jobs?company=${company.id}`}>
                      <Button variant="outline" data-testid="button-view-all-jobs">
                        Xem tất cả {jobs.length} vị trí tại {company.name}
                      </Button>
                    </Link>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Company Culture Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Môi trường làm việc</CardTitle>
            </CardHeader>
            <CardContent>
              <img
                src="https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300"
                alt="Creative workspace"
                className="rounded-lg w-full h-48 object-cover mb-4"
              />
              <p className="text-gray-700 text-sm">
                Văn phòng hiện đại với không gian mở, khuyến khích sự sáng tạo và hợp tác giữa các thành viên.
                Môi trường làm việc năng động và thân thiện, tạo điều kiện tốt nhất cho sự phát triển của nhân viên.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cơ hội phát triển</CardTitle>
            </CardHeader>
            <CardContent>
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300"
                alt="Team collaboration"
                className="rounded-lg w-full h-48 object-cover mb-4"
              />
              <div className="space-y-3">
                <div className="flex items-center text-sm text-gray-700">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  <span>Chương trình đào tạo và phát triển kỹ năng</span>
                </div>
                <div className="flex items-center text-sm text-gray-700">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  <span>Cơ hội thăng tiến rõ ràng</span>
                </div>
                <div className="flex items-center text-sm text-gray-700">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  <span>Làm việc với các chuyên gia hàng đầu</span>
                </div>
                <div className="flex items-center text-sm text-gray-700">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  <span>Tham gia các dự án thử thách</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <Card className="mt-8 bg-gradient-to-r from-primary to-blue-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Quan tâm đến {company.name}?</h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Khám phá các cơ hội nghề nghiệp tuyệt vời và bắt đầu hành trình sự nghiệp của bạn tại một trong những công ty hàng đầu.
            </p>
            <div className="flex items-center justify-center space-x-4">
              <Link href={`/jobs?company=${company.id}`}>
                <Button
                  variant="secondary"
                  className="bg-white text-primary hover:bg-gray-100"
                  data-testid="button-view-company-jobs"
                >
                  Xem tất cả việc làm
                </Button>
              </Link>
              {company.website && (
                <a
                  href={company.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex"
                >
                  <Button
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-primary"
                    data-testid="button-visit-website"
                  >
                    Thăm website
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                </a>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
