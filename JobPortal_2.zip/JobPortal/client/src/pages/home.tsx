import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { GraduationCap, Clock, Briefcase, UserPlus, Search, Send, Handshake, ArrowRight, Bell, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { JobWithCompany, Company } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import Hero from "@/components/hero";
import JobCard from "@/components/job-card";
import CompanyCard from "@/components/company-card";
import Footer from "@/components/footer";
import { Link } from "wouter";
import { FaMicrosoft, FaApple, FaAmazon, FaFacebook, FaSpotify } from "react-icons/fa";
import { SiNetflix } from "react-icons/si";

export default function Home() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [isSubscribing, setIsSubscribing] = useState(false);

  const { data: featuredJobs = [], isLoading: jobsLoading } = useQuery<JobWithCompany[]>({
    queryKey: ["/api/jobs"],
  });

  const { data: companies = [], isLoading: companiesLoading } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập email của bạn",
        variant: "destructive",
      });
      return;
    }

    setIsSubscribing(true);
    try {
      await apiRequest("POST", "/api/newsletter", { email, categories: selectedCategories });
      toast({
        title: "Thành công!",
        description: "Bạn đã đăng ký nhận thông báo việc làm thành công!",
      });
      setEmail("");
      setSelectedCategories([]);
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Có lỗi xảy ra, vui lòng thử lại sau.",
        variant: "destructive",
      });
    } finally {
      setIsSubscribing(false);
    }
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category]);
    } else {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    }
  };

  const jobCategories = [
    {
      icon: GraduationCap,
      title: "Thực Tập",
      description: "Trải nghiệm thực tế, học hỏi từ các chuyên gia và xây dựng mạng lưới quan hệ",
      count: "1,234 vị trí",
      color: "from-blue-50 to-indigo-50",
      iconBg: "bg-primary",
      textColor: "text-primary",
    },
    {
      icon: Clock,
      title: "Part-time",
      description: "Làm việc linh hoạt, cân bằng giữa học tập và kiếm thu nhập",
      count: "856 vị trí",
      color: "from-green-50 to-emerald-50",
      iconBg: "bg-accent",
      textColor: "text-accent",
    },
    {
      icon: Briefcase,
      title: "Full-time",
      description: "Cơ hội việc làm toàn thời gian cho sinh viên sắp tốt nghiệp",
      count: "432 vị trí",
      color: "from-purple-50 to-pink-50",
      iconBg: "bg-purple-500",
      textColor: "text-purple-500",
    },
  ];

  const workSteps = [
    {
      icon: UserPlus,
      title: "1. Tạo Hồ Sơ",
      description: "Đăng ký tài khoản và tạo hồ sơ cá nhân với thông tin học tập và kỹ năng",
      color: "bg-primary",
    },
    {
      icon: Search,
      title: "2. Tìm Kiếm",
      description: "Khám phá hàng nghìn cơ hội việc làm phù hợp với chuyên ngành và sở thích",
      color: "bg-accent",
    },
    {
      icon: Send,
      title: "3. Ứng Tuyển",
      description: "Gửi đơn ứng tuyển một cách nhanh chóng với CV và thư xin việc cá nhân hóa",
      color: "bg-purple-500",
    },
    {
      icon: Handshake,
      title: "4. Bắt Đầu",
      description: "Nhận phản hồi từ nhà tuyển dụng và bắt đầu hành trình sự nghiệp của bạn",
      color: "bg-orange-500",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <Hero />

      {/* Job Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Loại Hình Công Việc</h2>
            <p className="text-lg text-muted">Chọn loại công việc phù hợp với lịch học và kế hoạch của bạn</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {jobCategories.map((category) => {
              const Icon = category.icon;
              return (
                <div
                  key={category.title}
                  className={`bg-gradient-to-br ${category.color} p-8 rounded-xl hover:shadow-lg transition-shadow cursor-pointer`}
                  data-testid={`card-category-${category.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <div className={`w-12 h-12 ${category.iconBg} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className="text-white text-xl h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{category.title}</h3>
                  <p className="text-muted mb-4">{category.description}</p>
                  <div className={`flex items-center ${category.textColor} font-medium`}>
                    <span>{category.count}</span>
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Jobs */}
      <section className="py-16 bg-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Việc Làm Nổi Bật</h2>
              <p className="text-lg text-muted">Khám phá những cơ hội tuyệt vời từ các công ty hàng đầu</p>
            </div>
          </div>

          {jobsLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
              {featuredJobs.slice(0, 4).map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          )}

          <div className="text-center">
            <Link href="/jobs">
              <Button
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white"
                data-testid="button-view-all-jobs"
              >
                Xem Tất Cả Việc Làm <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Cách Thức Hoạt Động</h2>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Quy trình đơn giản để bắt đầu sự nghiệp của bạn trong 4 bước
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {workSteps.map((step) => {
              const Icon = step.icon;
              return (
                <div key={step.title} className="text-center" data-testid={`step-${step.title.split('.')[1].trim().toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className={`w-16 h-16 ${step.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <Icon className="text-white text-xl h-6 w-6" />
                  </div>
                  <h3 className="font-semibold text-lg text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-muted text-sm">{step.description}</p>
                </div>
              );
            })}
          </div>

          <div className="mt-12 text-center">
            <Button className="bg-primary text-white px-8 py-3 hover:bg-blue-600 font-medium text-lg" data-testid="button-get-started">
              Bắt Đầu Ngay <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Company Spotlight */}
      <section className="py-16 bg-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Các Công Ty Hàng Đầu</h2>
            <p className="text-lg text-muted">
              Được tin tưởng bởi những công ty tốt nhất đang tìm kiếm tài năng trẻ
            </p>
          </div>

          {companiesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-8 text-center">
                    <div className="h-32 bg-gray-200 rounded mb-4"></div>
                    <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-full mb-4"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {companies.slice(0, 3).map((company) => (
                <CompanyCard key={company.id} company={company} jobCount={45} />
              ))}
            </div>
          )}

          {/* Partner company logos */}
          <div className="border-t pt-8">
            <p className="text-center text-muted mb-8">Được tin tưởng bởi 500+ công ty hàng đầu</p>
            <div className="flex items-center justify-center space-x-12 opacity-60">
              <FaMicrosoft className="text-3xl text-gray-400" />
              <FaApple className="text-3xl text-gray-400" />
              <FaAmazon className="text-3xl text-gray-400" />
              <FaFacebook className="text-3xl text-gray-400" />
              <SiNetflix className="text-3xl text-gray-400" />
              <FaSpotify className="text-3xl text-gray-400" />
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-4">
                Không Bỏ Lỡ Cơ Hội Nào
              </h2>
              <p className="text-blue-100 text-lg mb-8">
                Đăng ký nhận thông báo về các vị trí việc làm mới phù hợp với bạn. 
                Hàng tuần chúng tôi sẽ gửi những cơ hội tốt nhất dành cho sinh viên.
              </p>
              
              <div className="flex items-center text-blue-100 text-sm space-x-6 mb-8">
                <div className="flex items-center">
                  <Check className="h-4 w-4 mr-2" />
                  <span>Việc làm phù hợp</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 mr-2" />
                  <span>Cập nhật hàng tuần</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 mr-2" />
                  <span>Miễn phí hoàn toàn</span>
                </div>
              </div>
            </div>

            <div className="mt-8 lg:mt-0">
              <div className="bg-white rounded-xl p-8 shadow-xl">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Đăng Ký Ngay</h3>
                <form onSubmit={handleNewsletterSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="newsletter-email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email của bạn
                    </Label>
                    <Input
                      id="newsletter-email"
                      type="email"
                      placeholder="your.email@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full"
                      data-testid="input-newsletter-email"
                    />
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-gray-700 mb-2">Quan tâm đến</Label>
                    <div className="space-y-2">
                      {["internship", "part-time", "full-time"].map((category) => (
                        <div key={category} className="flex items-center space-x-2">
                          <Checkbox
                            id={`category-${category}`}
                            checked={selectedCategories.includes(category)}
                            onCheckedChange={(checked) => handleCategoryChange(category, checked as boolean)}
                            data-testid={`checkbox-${category}`}
                          />
                          <Label htmlFor={`category-${category}`} className="text-sm text-gray-600 capitalize">
                            {category === "internship" ? "Thực tập" : category === "part-time" ? "Part-time" : "Full-time"}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <Button
                    type="submit"
                    disabled={isSubscribing}
                    className="w-full bg-primary text-white hover:bg-blue-600 font-medium"
                    data-testid="button-newsletter-submit"
                  >
                    {isSubscribing ? "Đang đăng ký..." : "Đăng Ký Nhận Thông Báo"} <Bell className="ml-2 h-4 w-4" />
                  </Button>
                </form>
                
                <p className="text-xs text-gray-500 text-center mt-4">
                  Bằng cách đăng ký, bạn đồng ý với{" "}
                  <a href="#" className="text-primary hover:underline" data-testid="link-terms">
                    Điều khoản sử dụng
                  </a>{" "}
                  và{" "}
                  <a href="#" className="text-primary hover:underline" data-testid="link-privacy-policy">
                    Chính sách bảo mật
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
