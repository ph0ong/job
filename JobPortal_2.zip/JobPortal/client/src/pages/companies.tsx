import { useQuery } from "@tanstack/react-query";
import { Search, Users, MapPin, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Company } from "@shared/schema";
import Header from "@/components/header";
import Footer from "@/components/footer";
import CompanyCard from "@/components/company-card";
import { useState } from "react";

export default function Companies() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: companies = [], isLoading } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const filteredCompanies = companies.filter(company =>
    company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    company.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
    company.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  const industries = Array.from(new Set(companies.map(c => c.industry)));
  const locations = Array.from(new Set(companies.map(c => c.location)));

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="bg-light py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Các Công Ty Hàng Đầu</h1>
            <p className="text-lg text-muted">
              Khám phá {filteredCompanies.length} công ty đang tuyển dụng sinh viên
            </p>
          </div>

          {/* Search */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <form onSubmit={handleSearch}>
                <div className="flex gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Tìm kiếm công ty theo tên, ngành nghề, địa điểm..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                      data-testid="input-company-search"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="bg-primary text-white hover:bg-blue-600"
                    data-testid="button-search-companies"
                  >
                    Tìm kiếm
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <Briefcase className="h-8 w-8 text-primary mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900" data-testid="text-total-companies">
                  {companies.length}
                </div>
                <div className="text-sm text-gray-600">Công ty</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <Users className="h-8 w-8 text-accent mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900" data-testid="text-total-industries">
                  {industries.length}
                </div>
                <div className="text-sm text-gray-600">Ngành nghề</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <MapPin className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900" data-testid="text-total-locations">
                  {locations.length}
                </div>
                <div className="text-sm text-gray-600">Thành phố</div>
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div className="flex items-center justify-between mb-6">
            <p className="text-gray-600" data-testid="text-company-results">
              Hiển thị {filteredCompanies.length} kết quả
            </p>
          </div>

          {/* Company Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-8 text-center">
                    <div className="h-32 bg-gray-200 rounded mb-4"></div>
                    <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-full mb-4"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredCompanies.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Không tìm thấy công ty</h3>
                <p className="text-gray-600 mb-4">
                  Thử tìm kiếm với từ khóa khác
                </p>
                <Button onClick={() => setSearchQuery("")} variant="outline" data-testid="button-clear-company-search">
                  Xóa tìm kiếm
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {filteredCompanies.map((company) => (
                <CompanyCard key={company.id} company={company} jobCount={Math.floor(Math.random() * 50) + 10} />
              ))}
            </div>
          )}

          {/* Popular Industries */}
          {industries.length > 0 && (
            <div className="border-t pt-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Ngành nghề phổ biến</h3>
              <div className="flex flex-wrap gap-3">
                {industries.map((industry) => (
                  <Button
                    key={industry}
                    variant="outline"
                    size="sm"
                    onClick={() => setSearchQuery(industry)}
                    className="hover:bg-primary hover:text-white"
                    data-testid={`button-industry-${industry.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {industry}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
