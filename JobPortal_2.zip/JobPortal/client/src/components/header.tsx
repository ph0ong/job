import { Link, useLocation } from "wouter";
import { Briefcase, Menu, X, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";

export default function Header() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const { user, isLoading, isAuthenticated } = useAuth();

  const navigation = [
    { name: "Việc Làm", href: "/jobs" },
    { name: "Công Ty", href: "/companies" },
    { name: "Hướng Dẫn", href: "#" },
    { name: "Blog", href: "#" },
  ];

  const NavLinks = ({ mobile = false }) => (
    <>
      {navigation.map((item) => (
        <Link
          key={item.name}
          href={item.href}
          className={`${
            mobile ? "block px-3 py-2" : ""
          } text-gray-700 hover:text-primary transition-colors ${
            location === item.href ? "text-primary font-medium" : ""
          }`}
          onClick={() => mobile && setIsOpen(false)}
        >
          {item.name}
        </Link>
      ))}
    </>
  );

  return (
    <header className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center">
            <Briefcase className="h-8 w-8 text-primary mr-2" />
            <span className="text-xl font-bold text-gray-900">StudentJobs</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <NavLinks />
          </nav>

          <div className="flex items-center space-x-4">
            {isLoading ? (
              <div className="w-8 h-8 rounded-full bg-gray-200 animate-pulse"></div>
            ) : isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full" data-testid="button-user-menu">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
                      <AvatarFallback>
                        {user?.firstName ? user.firstName[0] : user?.email?.[0] || <User className="h-4 w-4" />}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuItem className="flex flex-col items-start">
                    <div className="font-medium">
                      {user?.firstName && user?.lastName 
                        ? `${user.firstName} ${user.lastName}` 
                        : user?.firstName || "Người dùng"}
                    </div>
                    {user?.email && (
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                    )}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => window.location.href = '/api/logout'} data-testid="button-logout">
                    Đăng Xuất
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button
                  variant="ghost"
                  className="hidden sm:block text-gray-700 hover:text-primary"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-login"
                >
                  Đăng Nhập
                </Button>
                <Button
                  className="bg-primary text-white hover:bg-blue-600"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-register"
                >
                  Đăng Ký
                </Button>
              </>
            )}

            {/* Mobile menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col space-y-4 mt-8">
                  <NavLinks mobile />
                  <div className="pt-4 border-t space-y-2">
                    {isLoading ? (
                      <div className="w-full h-10 rounded bg-gray-200 animate-pulse"></div>
                    ) : isAuthenticated && user ? (
                      <>
                        <div className="px-3 py-2 text-sm">
                          <div className="font-medium">
                            {user?.firstName && user?.lastName 
                              ? `${user.firstName} ${user.lastName}` 
                              : user?.firstName || "Người dùng"}
                          </div>
                          {user?.email && (
                            <div className="text-muted-foreground">{user.email}</div>
                          )}
                        </div>
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start"
                          onClick={() => window.location.href = '/api/logout'}
                          data-testid="button-mobile-logout"
                        >
                          Đăng Xuất
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          className="w-full justify-start"
                          onClick={() => window.location.href = '/api/login'}
                          data-testid="button-mobile-login"
                        >
                          Đăng Nhập
                        </Button>
                        <Button 
                          className="w-full bg-primary text-white hover:bg-blue-600" 
                          onClick={() => window.location.href = '/api/login'}
                          data-testid="button-mobile-register"
                        >
                          Đăng Ký
                        </Button>
                      </>
                    )}
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
