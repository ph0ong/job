import { useState } from "react";
import { Search, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useLocation } from "wouter";

export default function Hero() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchQuery) params.set("search", searchQuery);
    if (selectedLocation) params.set("location", selectedLocation);
    setLocation(`/jobs?${params.toString()}`);
  };

  const popularTags = ["Marketing", "IT", "Design"];

  return (
    <section className="bg-gradient-to-br from-light to-blue-50 py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
          <div className="max-w-md mx-auto lg:max-w-none lg:mx-0">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight mb-6">
              Tìm Việc Làm <span className="text-primary">Dành Cho Sinh Viên</span>
            </h1>
            <p className="text-lg text-muted mb-8">
              Khám phá hàng nghìn cơ hội thực tập, part-time và full-time từ các công ty hàng đầu. 
              Bắt đầu sự nghiệp của bạn ngay hôm nay!
            </p>

            {/* Search Form */}
            <form onSubmit={handleSearch} className="bg-white rounded-xl shadow-lg p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1">
                  <Label htmlFor="search-position" className="block text-sm font-medium text-gray-700 mb-2">
                    Vị trí
                  </Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="search-position"
                      type="text"
                      placeholder="Tên công việc, kỹ năng..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                      data-testid="input-search-position"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="search-location" className="block text-sm font-medium text-gray-700 mb-2">
                    Địa điểm
                  </Label>
                  <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                    <SelectTrigger className="w-full" data-testid="select-location">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                        <SelectValue placeholder="Chọn địa điểm" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Ho Chi Minh">Hồ Chí Minh</SelectItem>
                      <SelectItem value="Ha Noi">Hà Nội</SelectItem>
                      <SelectItem value="Da Nang">Đà Nẵng</SelectItem>
                      <SelectItem value="Remote">Remote</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    type="submit"
                    className="w-full bg-primary text-white hover:bg-blue-600 font-medium"
                    data-testid="button-search"
                  >
                    Tìm Kiếm
                  </Button>
                </div>
              </div>
            </form>

            <div className="flex items-center text-sm text-muted">
              <span>Phổ biến:</span>
              <div className="ml-2 space-x-2">
                {popularTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      setSearchQuery(tag);
                      const params = new URLSearchParams();
                      params.set("search", tag);
                      setLocation(`/jobs?${params.toString()}`);
                    }}
                    className="bg-gray-100 px-3 py-1 rounded-full hover:bg-gray-200 transition-colors"
                    data-testid={`tag-${tag.toLowerCase()}`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-12 lg:mt-0">
            <img
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Students collaborating and job searching"
              className="rounded-xl shadow-2xl w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
