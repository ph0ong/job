import { Briefcase } from "lucide-react";
import { FaFacebook, FaLinkedin, FaInstagram, FaTwitter } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <Briefcase className="h-8 w-8 text-primary mr-2" />
              <span className="text-xl font-bold">StudentJobs</span>
            </div>
            <p className="text-gray-400 mb-4">
              Nền tảng tuyển dụng hàng đầu dành cho sinh viên tại Việt Nam. 
              Kết nối tài năng trẻ với những cơ hội nghề nghiệp tuyệt vời.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-facebook">
                <FaFacebook className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-linkedin">
                <FaLinkedin className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-instagram">
                <FaInstagram className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-twitter">
                <FaTwitter className="text-xl" />
              </a>
            </div>
          </div>

          {/* For Students */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Dành cho Sinh viên</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="/jobs" className="hover:text-white transition-colors" data-testid="link-find-jobs">Tìm việc làm</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-create-cv">Tạo CV</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-application-guide">Hướng dẫn ứng tuyển</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-career-skills">Kỹ năng nghề nghiệp</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-career-advice">Tư vấn sự nghiệp</a></li>
            </ul>
          </div>

          {/* For Employers */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Dành cho Nhà tuyển dụng</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-post-job">Đăng tin tuyển dụng</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-find-candidates">Tìm ứng viên</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-packages">Gói dịch vụ</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-recruitment-management">Quản lý tuyển dụng</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-contact-sales">Liên hệ sales</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Hỗ trợ</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-support-center">Trung tâm hỗ trợ</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-contact">Liên hệ</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-faq">FAQ</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-terms">Điều khoản sử dụng</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="link-privacy">Chính sách bảo mật</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 StudentJobs Vietnam. Tất cả quyền được bảo lưu.
            </p>
            <div className="mt-4 md:mt-0 flex items-center space-x-6 text-sm text-gray-400">
              <span>🇻🇳 Tiếng Việt</span>
              <span data-testid="text-job-count">💼 2,547 việc làm</span>
              <span data-testid="text-company-count">🏢 847 công ty</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
