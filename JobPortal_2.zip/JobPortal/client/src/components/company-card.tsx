import { Users, Briefcase, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Company } from "@shared/schema";
import { Link } from "wouter";

interface CompanyCardProps {
  company: Company;
  jobCount?: number;
}

export default function CompanyCard({ company, jobCount = 0 }: CompanyCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow text-center" data-testid={`card-company-${company.id}`}>
      <CardContent className="p-8">
        <img
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200"
          alt="Company office"
          className="rounded-lg w-full h-32 object-cover mb-4"
        />
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <img
            src={company.logo || "https://images.unsplash.com/photo-1549924231-f129b911e442?w=100&h=100&fit=crop&crop=center"}
            alt={company.name}
            className="w-12 h-12 rounded-full object-cover"
          />
        </div>
        <h3 className="font-semibold text-xl text-gray-900 mb-2" data-testid={`text-company-name-${company.id}`}>
          {company.name}
        </h3>
        <p className="text-muted text-sm mb-4 line-clamp-3" data-testid={`text-company-description-${company.id}`}>
          {company.description}
        </p>
        <div className="flex justify-center space-x-4 text-sm text-muted mb-4">
          <span data-testid={`text-company-size-${company.id}`}>
            <Users className="inline h-4 w-4 mr-1" />
            {company.size}
          </span>
          <span data-testid={`text-company-jobs-${company.id}`}>
            <Briefcase className="inline h-4 w-4 mr-1" />
            {jobCount} vị trí
          </span>
        </div>
        <Link href={`/companies/${company.id}`}>
          <Button variant="ghost" className="text-primary hover:text-blue-600" data-testid={`button-company-jobs-${company.id}`}>
            Xem Việc Làm <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
