import { Clock, MapPin, DollarSign, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { JobWithCompany } from "@shared/schema";
import { Link } from "wouter";

interface JobCardProps {
  job: JobWithCompany;
}

export default function JobCard({ job }: JobCardProps) {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "internship":
        return "bg-green-100 text-green-800";
      case "part-time":
        return "bg-blue-100 text-blue-800";
      case "full-time":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "internship":
        return "Thực tập";
      case "part-time":
        return "Part-time";
      case "full-time":
        return "Full-time";
      default:
        return type;
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow" data-testid={`card-job-${job.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <img
                src={job.company.logo || "https://images.unsplash.com/photo-1549924231-f129b911e442?w=100&h=100&fit=crop&crop=center"}
                alt={job.company.name}
                className="w-8 h-8 rounded object-cover"
              />
            </div>
            <div className="ml-4">
              <h3 className="font-semibold text-lg text-gray-900" data-testid={`text-job-title-${job.id}`}>
                {job.title}
              </h3>
              <p className="text-muted" data-testid={`text-company-name-${job.id}`}>
                {job.company.name}
              </p>
            </div>
          </div>
          <Badge className={getTypeColor(job.type)}>
            {getTypeLabel(job.type)}
          </Badge>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2" data-testid={`text-job-description-${job.id}`}>
          {job.description}
        </p>
        
        <div className="flex items-center text-sm text-muted mb-4 space-x-4">
          <div className="flex items-center">
            <MapPin className="h-4 w-4 mr-1" />
            <span data-testid={`text-job-location-${job.id}`}>{job.location}</span>
          </div>
          {job.salary && (
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 mr-1" />
              <span data-testid={`text-job-salary-${job.id}`}>{job.salary}</span>
            </div>
          )}
          {job.duration && (
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              <span data-testid={`text-job-duration-${job.id}`}>{job.duration}</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            {job.skills.slice(0, 2).map((skill) => (
              <Badge key={skill} variant="secondary" className="text-xs">
                {skill}
              </Badge>
            ))}
            {job.skills.length > 2 && (
              <Badge variant="secondary" className="text-xs">
                +{job.skills.length - 2}
              </Badge>
            )}
          </div>
          <Link href={`/jobs/${job.id}`}>
            <Button variant="ghost" className="text-primary hover:text-blue-600 p-0" data-testid={`button-job-details-${job.id}`}>
              Xem Chi Tiết <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
