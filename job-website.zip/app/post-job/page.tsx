"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Building2, MapPin, DollarSign, Clock, Briefcase, Plus, X, ArrowLeft, Save, Eye } from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

interface JobFormData {
  title: string
  company: string
  location: string
  jobType: string
  workMode: string
  experience: string
  education: string
  salaryMin: string
  salaryMax: string
  currency: string
  category: string
  description: string
  requirements: string
  benefits: string
  applicationDeadline: string
  contactEmail: string
  contactPhone: string
  isUrgent: boolean
  isRemote: boolean
}

export default function PostJobPage() {
  const [skills, setSkills] = useState<string[]>([])
  const [newSkill, setNewSkill] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [previewMode, setPreviewMode] = useState(false)

  const form = useForm<JobFormData>({
    defaultValues: {
      title: "",
      company: "",
      location: "",
      jobType: "",
      workMode: "",
      experience: "",
      education: "",
      salaryMin: "",
      salaryMax: "",
      currency: "VND",
      category: "",
      description: "",
      requirements: "",
      benefits: "",
      applicationDeadline: "",
      contactEmail: "",
      contactPhone: "",
      isUrgent: false,
      isRemote: false,
    },
  })

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove))
  }

  const onSubmit = async (data: JobFormData) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))
      console.log("Job posted:", { ...data, skills })
      // Redirect to job management or success page
      alert("Tin tuyển dụng đã được đăng thành công!")
    } catch (error) {
      console.error("Error posting job:", error)
      alert("Có lỗi xảy ra. Vui lòng thử lại.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSkillKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      addSkill()
    }
  }

  if (previewMode) {
    const formData = form.getValues()
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 bg-muted/30">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center gap-4 mb-8">
              <Button variant="ghost" size="sm" onClick={() => setPreviewMode(false)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Quay lại chỉnh sửa
              </Button>
              <h1 className="text-2xl font-bold">Xem trước tin đăng</h1>
            </div>

            <Card className="max-w-4xl mx-auto">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl mb-2">{formData.title || "Tiêu đề công việc"}</CardTitle>
                    <div className="flex items-center gap-2 text-muted-foreground mb-4">
                      <Building2 className="h-4 w-4" />
                      <span>{formData.company || "Tên công ty"}</span>
                    </div>
                  </div>
                  {formData.isUrgent && <Badge variant="destructive">Tuyển gấp</Badge>}
                </div>

                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{formData.location || "Địa điểm"}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <DollarSign className="h-4 w-4" />
                    <span>
                      {formData.salaryMin && formData.salaryMax
                        ? `${formData.salaryMin}-${formData.salaryMax} ${formData.currency}`
                        : "Thỏa thuận"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{formData.experience || "Kinh nghiệm"}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Briefcase className="h-4 w-4" />
                    <span>{formData.jobType || "Loại hình"}</span>
                  </div>
                </div>

                {skills.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {skills.map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardHeader>

              <CardContent className="space-y-6">
                {formData.description && (
                  <div>
                    <h3 className="font-semibold mb-2">Mô tả công việc</h3>
                    <div className="text-muted-foreground whitespace-pre-wrap">{formData.description}</div>
                  </div>
                )}

                {formData.requirements && (
                  <div>
                    <h3 className="font-semibold mb-2">Yêu cầu ứng viên</h3>
                    <div className="text-muted-foreground whitespace-pre-wrap">{formData.requirements}</div>
                  </div>
                )}

                {formData.benefits && (
                  <div>
                    <h3 className="font-semibold mb-2">Quyền lợi</h3>
                    <div className="text-muted-foreground whitespace-pre-wrap">{formData.benefits}</div>
                  </div>
                )}

                <div className="flex gap-4 pt-4">
                  <Button className="flex-1">Ứng tuyển ngay</Button>
                  <Button variant="outline" className="bg-transparent">
                    Lưu tin
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/30">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Quay lại
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Đăng tin tuyển dụng</h1>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-4xl mx-auto">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Thông tin cơ bản</CardTitle>
                  <CardDescription>Nhập thông tin cơ bản về vị trí tuyển dụng</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tiêu đề công việc *</FormLabel>
                          <FormControl>
                            <Input placeholder="VD: Senior Frontend Developer" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tên công ty *</FormLabel>
                          <FormControl>
                            <Input placeholder="VD: TechViet Solutions" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Danh mục *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Chọn danh mục" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="it-software">IT - Phần mềm</SelectItem>
                              <SelectItem value="marketing">Marketing</SelectItem>
                              <SelectItem value="design">Thiết kế</SelectItem>
                              <SelectItem value="sales">Bán hàng</SelectItem>
                              <SelectItem value="accounting">Kế toán</SelectItem>
                              <SelectItem value="hr">Nhân sự</SelectItem>
                              <SelectItem value="management">Quản lý</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Địa điểm làm việc *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Chọn địa điểm" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="TP. Hồ Chí Minh">TP. Hồ Chí Minh</SelectItem>
                              <SelectItem value="Hà Nội">Hà Nội</SelectItem>
                              <SelectItem value="Đà Nẵng">Đà Nẵng</SelectItem>
                              <SelectItem value="Hải Phòng">Hải Phòng</SelectItem>
                              <SelectItem value="Cần Thơ">Cần Thơ</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="jobType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Loại hình công việc *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Chọn loại hình" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="full-time">Full-time</SelectItem>
                              <SelectItem value="part-time">Part-time</SelectItem>
                              <SelectItem value="contract">Hợp đồng</SelectItem>
                              <SelectItem value="internship">Thực tập</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="workMode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hình thức làm việc</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Chọn hình thức" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="onsite">Tại văn phòng</SelectItem>
                              <SelectItem value="remote">Remote</SelectItem>
                              <SelectItem value="hybrid">Hybrid</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex items-center space-x-6">
                    <FormField
                      control={form.control}
                      name="isUrgent"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Tuyển gấp</FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="isRemote"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Cho phép làm việc từ xa</FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Requirements */}
              <Card>
                <CardHeader>
                  <CardTitle>Yêu cầu ứng viên</CardTitle>
                  <CardDescription>Mô tả chi tiết về yêu cầu đối với ứng viên</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="experience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Kinh nghiệm *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Chọn kinh nghiệm" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="0-1 năm">0-1 năm</SelectItem>
                              <SelectItem value="1-3 năm">1-3 năm</SelectItem>
                              <SelectItem value="3-5 năm">3-5 năm</SelectItem>
                              <SelectItem value="5+ năm">5+ năm</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="education"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Trình độ học vấn</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Chọn trình độ" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="high-school">Trung học phổ thông</SelectItem>
                              <SelectItem value="college">Cao đẳng</SelectItem>
                              <SelectItem value="bachelor">Đại học</SelectItem>
                              <SelectItem value="master">Thạc sĩ</SelectItem>
                              <SelectItem value="phd">Tiến sĩ</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Skills */}
                  <div className="space-y-4">
                    <FormLabel>Kỹ năng yêu cầu</FormLabel>
                    <div className="flex flex-wrap gap-2">
                      {skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                          {skill}
                          <button
                            type="button"
                            onClick={() => removeSkill(skill)}
                            className="ml-1 hover:bg-destructive/20 rounded-full p-0.5"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Input
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        placeholder="Thêm kỹ năng..."
                        onKeyDown={handleSkillKeyPress}
                      />
                      <Button type="button" onClick={addSkill}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Salary */}
              <Card>
                <CardHeader>
                  <CardTitle>Mức lương</CardTitle>
                  <CardDescription>Thông tin về mức lương và quyền lợi</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="salaryMin"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Lương tối thiểu</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="15000000" {...field} />
                          </FormControl>
                          <FormDescription>Để trống nếu thỏa thuận</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="salaryMax"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Lương tối đa</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="25000000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Đơn vị tiền tệ</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="VND">VND</SelectItem>
                              <SelectItem value="USD">USD</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Job Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Chi tiết công việc</CardTitle>
                  <CardDescription>Mô tả chi tiết về công việc và quyền lợi</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mô tả công việc *</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Mô tả chi tiết về công việc, trách nhiệm và yêu cầu..."
                            className="min-h-[120px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="requirements"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Yêu cầu chi tiết</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Liệt kê các yêu cầu cụ thể về kỹ năng, kinh nghiệm..."
                            className="min-h-[120px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="benefits"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quyền lợi</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Mô tả các quyền lợi, phúc lợi mà ứng viên sẽ nhận được..."
                            className="min-h-[120px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Contact & Deadline */}
              <Card>
                <CardHeader>
                  <CardTitle>Thông tin liên hệ</CardTitle>
                  <CardDescription>Thông tin để ứng viên liên hệ và hạn nộp hồ sơ</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="contactEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email liên hệ *</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="hr@company.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="contactPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Số điện thoại</FormLabel>
                          <FormControl>
                            <Input placeholder="0123456789" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="applicationDeadline"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hạn nộp hồ sơ</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Submit Buttons */}
              <div className="flex gap-4 justify-end">
                <Button type="button" variant="outline" onClick={() => setPreviewMode(true)}>
                  <Eye className="h-4 w-4 mr-2" />
                  Xem trước
                </Button>
                <Button type="submit" disabled={isLoading}>
                  <Save className="h-4 w-4 mr-2" />
                  {isLoading ? "Đang đăng..." : "Đăng tin"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </main>

      <Footer />
    </div>
  )
}
