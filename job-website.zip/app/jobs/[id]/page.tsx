"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  MapPin,
  Clock,
  DollarSign,
  Building2,
  Users,
  Calendar,
  Bookmark,
  Share2,
  ArrowLeft,
  CheckCircle,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

// Mock data - trong thực tế sẽ fetch từ API
const jobData = {
  id: 1,
  title: "Senior Frontend Developer",
  company: "TechViet Solutions",
  location: "TP. Hồ Chí Minh",
  salary: "25-35 triệu",
  type: "Full-time",
  logo: "/abstract-tech-logo.png",
  tags: ["React", "TypeScript", "Next.js"],
  posted: "2 ngày trước",
  deadline: "30/12/2024",
  experience: "3-5 năm",
  level: "Senior",
  employees: "100-500 nhân viên",
  description: `
    <h3>Mô tả công việc</h3>
    <ul>
      <li>Phát triển và duy trì các ứng dụng web frontend sử dụng React, TypeScript và Next.js</li>
      <li>Hợp tác chặt chẽ với team UX/UI để triển khai các thiết kế responsive</li>
      <li>Tối ưu hóa hiệu suất ứng dụng và trải nghiệm người dùng</li>
      <li>Code review và mentor các developer junior</li>
      <li>Tham gia vào việc thiết kế kiến trúc frontend</li>
    </ul>
  `,
  requirements: `
    <h3>Yêu cầu ứng viên</h3>
    <ul>
      <li>Tối thiểu 3 năm kinh nghiệm với React và TypeScript</li>
      <li>Kinh nghiệm với Next.js, Redux/Zustand</li>
      <li>Thành thạo HTML5, CSS3, JavaScript ES6+</li>
      <li>Hiểu biết về RESTful APIs và GraphQL</li>
      <li>Kinh nghiệm với Git, CI/CD</li>
      <li>Khả năng làm việc nhóm tốt</li>
    </ul>
  `,
  benefits: `
    <h3>Quyền lợi</h3>
    <ul>
      <li>Lương cạnh tranh: 25-35 triệu VND</li>
      <li>Thưởng hiệu suất, thưởng dự án</li>
      <li>Bảo hiểm sức khỏe cao cấp</li>
      <li>Môi trường làm việc hiện đại, năng động</li>
      <li>Cơ hội đào tạo và phát triển nghề nghiệp</li>
      <li>Team building, du lịch công ty</li>
    </ul>
  `,
}

export default function JobDetailPage({ params }: { params: { id: string } }) {
  const [isBookmarked, setIsBookmarked] = useState(false)
  const [hasApplied, setHasApplied] = useState(false)

  const handleApply = () => {
    setHasApplied(true)
    // Logic ứng tuyển
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-6">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Quay lại
              </Button>
            </Link>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            {/* Job Info */}
            <div className="flex-1">
              <div className="flex items-start gap-4">
                <img
                  src={jobData.logo || "/placeholder.svg"}
                  alt={`${jobData.company} logo`}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">{jobData.title}</h1>
                  <div className="flex items-center gap-2 text-lg text-muted-foreground mb-4">
                    <Building2 className="h-5 w-5" />
                    <span>{jobData.company}</span>
                  </div>

                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{jobData.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      <span>{jobData.salary}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{jobData.experience}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{jobData.employees}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-4">
                {jobData.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-3 lg:w-64">
              <Button size="lg" className="w-full" onClick={handleApply} disabled={hasApplied}>
                {hasApplied ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Đã ứng tuyển
                  </>
                ) : (
                  "Ứng tuyển ngay"
                )}
              </Button>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 bg-transparent"
                  onClick={() => setIsBookmarked(!isBookmarked)}
                >
                  <Bookmark className={`h-4 w-4 mr-2 ${isBookmarked ? "fill-current" : ""}`} />
                  {isBookmarked ? "Đã lưu" : "Lưu"}
                </Button>
                <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                  <Share2 className="h-4 w-4 mr-2" />
                  Chia sẻ
                </Button>
              </div>

              <div className="text-xs text-muted-foreground text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Calendar className="h-3 w-3" />
                  <span>Hạn nộp: {jobData.deadline}</span>
                </div>
                <span>Đăng {jobData.posted}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: jobData.description }} />
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: jobData.requirements }} />
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: jobData.benefits }} />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Company Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Thông tin công ty</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <img
                    src={jobData.logo || "/placeholder.svg"}
                    alt={`${jobData.company} logo`}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div>
                    <h3 className="font-semibold">{jobData.company}</h3>
                    <p className="text-sm text-muted-foreground">{jobData.employees}</p>
                  </div>
                </div>
                <Separator />
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{jobData.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                    <span>Công nghệ thông tin</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full bg-transparent">
                  Xem trang công ty
                </Button>
              </CardContent>
            </Card>

            {/* Similar Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Việc làm tương tự</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="space-y-2">
                    <h4 className="font-medium text-sm">Frontend Developer</h4>
                    <p className="text-xs text-muted-foreground">ABC Company • TP.HCM</p>
                    <p className="text-xs text-primary">20-30 triệu</p>
                    {i < 3 && <Separator />}
                  </div>
                ))}
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  Xem thêm
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
