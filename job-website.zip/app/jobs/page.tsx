"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin, DollarSign, Clock, Building2, SlidersHorizontal, X } from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

// Mock data - trong thực tế sẽ fetch từ API
const allJobs = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechViet Solutions",
    location: "TP. Hồ Chí Minh",
    salary: "25-35 triệu",
    salaryMin: 25000000,
    salaryMax: 35000000,
    type: "Full-time",
    experience: "3-5 năm",
    level: "Senior",
    logo: "/abstract-tech-logo.png",
    tags: ["React", "TypeScript", "Next.js"],
    posted: "2 ngày trước",
    category: "IT - Phần mềm",
  },
  {
    id: 2,
    title: "Marketing Manager",
    company: "Digital Marketing Pro",
    location: "Hà Nội",
    salary: "20-30 triệu",
    salaryMin: 20000000,
    salaryMax: 30000000,
    type: "Full-time",
    experience: "2-4 năm",
    level: "Middle",
    logo: "/marketing-company-logo.png",
    tags: ["Digital Marketing", "SEO", "Social Media"],
    posted: "1 ngày trước",
    category: "Marketing",
  },
  {
    id: 3,
    title: "UX/UI Designer",
    company: "Creative Studio",
    location: "Đà Nẵng",
    salary: "15-25 triệu",
    salaryMin: 15000000,
    salaryMax: 25000000,
    type: "Full-time",
    experience: "1-3 năm",
    level: "Junior",
    logo: "/design-studio-logo.png",
    tags: ["Figma", "Adobe XD", "Prototyping"],
    posted: "3 ngày trước",
    category: "Thiết kế",
  },
  {
    id: 4,
    title: "Data Analyst",
    company: "Analytics Corp",
    location: "TP. Hồ Chí Minh",
    salary: "18-28 triệu",
    salaryMin: 18000000,
    salaryMax: 28000000,
    type: "Full-time",
    experience: "2-4 năm",
    level: "Middle",
    logo: "/analytics-company-logo.png",
    tags: ["Python", "SQL", "Tableau"],
    posted: "1 ngày trước",
    category: "IT - Phần mềm",
  },
  {
    id: 5,
    title: "Product Manager",
    company: "StartupVN",
    location: "Hà Nội",
    salary: "30-45 triệu",
    salaryMin: 30000000,
    salaryMax: 45000000,
    type: "Full-time",
    experience: "3-5 năm",
    level: "Senior",
    logo: "/startup-logo.png",
    tags: ["Product Strategy", "Agile", "Analytics"],
    posted: "4 ngày trước",
    category: "Quản lý",
  },
  {
    id: 6,
    title: "DevOps Engineer",
    company: "CloudTech Vietnam",
    location: "TP. Hồ Chí Minh",
    salary: "25-40 triệu",
    salaryMin: 25000000,
    salaryMax: 40000000,
    type: "Full-time",
    experience: "3-5 năm",
    level: "Senior",
    logo: "/cloud-tech-logo.png",
    tags: ["AWS", "Docker", "Kubernetes"],
    posted: "2 ngày trước",
    category: "IT - Phần mềm",
  },
  {
    id: 7,
    title: "Junior Frontend Developer",
    company: "WebDev Studio",
    location: "Hà Nội",
    salary: "12-18 triệu",
    salaryMin: 12000000,
    salaryMax: 18000000,
    type: "Full-time",
    experience: "0-2 năm",
    level: "Junior",
    logo: "/webdev-logo.png",
    tags: ["HTML", "CSS", "JavaScript"],
    posted: "1 ngày trước",
    category: "IT - Phần mềm",
  },
  {
    id: 8,
    title: "Sales Executive",
    company: "SalesForce VN",
    location: "TP. Hồ Chí Minh",
    salary: "15-25 triệu",
    salaryMin: 15000000,
    salaryMax: 25000000,
    type: "Full-time",
    experience: "1-3 năm",
    level: "Junior",
    logo: "/sales-logo.png",
    tags: ["B2B Sales", "CRM", "Communication"],
    posted: "3 ngày trước",
    category: "Bán hàng",
  },
]

export default function JobsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedLocation, setSelectedLocation] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedExperience, setSelectedExperience] = useState("all")
  const [selectedJobType, setSelectedJobType] = useState("all")
  const [salaryRange, setSalaryRange] = useState("all")
  const [sortBy, setSortBy] = useState("newest")
  const [showFilters, setShowFilters] = useState(false)

  // Filter and search logic
  const filteredJobs = useMemo(() => {
    const filtered = allJobs.filter((job) => {
      const matchesSearch =
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

      const matchesLocation = selectedLocation === "all" || job.location === selectedLocation
      const matchesCategory = selectedCategory === "all" || job.category === selectedCategory
      const matchesExperience = selectedExperience === "all" || job.experience === selectedExperience
      const matchesJobType = selectedJobType === "all" || job.type === selectedJobType

      let matchesSalary = true
      if (salaryRange !== "all") {
        const [min, max] = salaryRange.split("-").map((s) => Number.parseInt(s) * 1000000)
        matchesSalary = job.salaryMin >= min && job.salaryMax <= max
      }

      return matchesSearch && matchesLocation && matchesCategory && matchesExperience && matchesJobType && matchesSalary
    })

    // Sort results
    switch (sortBy) {
      case "salary-high":
        filtered.sort((a, b) => b.salaryMax - a.salaryMax)
        break
      case "salary-low":
        filtered.sort((a, b) => a.salaryMin - b.salaryMin)
        break
      case "newest":
      default:
        // Keep original order (newest first)
        break
    }

    return filtered
  }, [searchQuery, selectedLocation, selectedCategory, selectedExperience, selectedJobType, salaryRange, sortBy])

  const clearFilters = () => {
    setSearchQuery("")
    setSelectedLocation("all")
    setSelectedCategory("all")
    setSelectedExperience("all")
    setSelectedJobType("all")
    setSalaryRange("all")
    setSortBy("newest")
  }

  const activeFiltersCount = [
    selectedLocation !== "all",
    selectedCategory !== "all",
    selectedExperience !== "all",
    selectedJobType !== "all",
    salaryRange !== "all",
  ].filter(Boolean).length

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Search Header */}
        <div className="bg-gradient-to-br from-primary/5 via-background to-accent/5 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-center">Tìm kiếm việc làm</h1>

              {/* Search Form */}
              <div className="bg-card rounded-xl p-6 shadow-lg border">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="md:col-span-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Vị trí, công ty, từ khóa..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 h-12"
                      />
                    </div>
                  </div>

                  <div>
                    <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                      <SelectTrigger className="h-12">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <SelectValue placeholder="Địa điểm" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tất cả địa điểm</SelectItem>
                        <SelectItem value="TP. Hồ Chí Minh">TP. Hồ Chí Minh</SelectItem>
                        <SelectItem value="Hà Nội">Hà Nội</SelectItem>
                        <SelectItem value="Đà Nẵng">Đà Nẵng</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Button
                      variant="outline"
                      className="w-full h-12 bg-transparent"
                      onClick={() => setShowFilters(!showFilters)}
                    >
                      <SlidersHorizontal className="h-4 w-4 mr-2" />
                      Bộ lọc {activeFiltersCount > 0 && `(${activeFiltersCount})`}
                    </Button>
                  </div>
                </div>

                {/* Advanced Filters */}
                {showFilters && (
                  <div className="mt-6 pt-6 border-t">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                          <SelectTrigger>
                            <SelectValue placeholder="Danh mục" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Tất cả danh mục</SelectItem>
                            <SelectItem value="IT - Phần mềm">IT - Phần mềm</SelectItem>
                            <SelectItem value="Marketing">Marketing</SelectItem>
                            <SelectItem value="Thiết kế">Thiết kế</SelectItem>
                            <SelectItem value="Bán hàng">Bán hàng</SelectItem>
                            <SelectItem value="Quản lý">Quản lý</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Select value={selectedExperience} onValueChange={setSelectedExperience}>
                          <SelectTrigger>
                            <SelectValue placeholder="Kinh nghiệm" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Tất cả kinh nghiệm</SelectItem>
                            <SelectItem value="0-2 năm">0-2 năm</SelectItem>
                            <SelectItem value="1-3 năm">1-3 năm</SelectItem>
                            <SelectItem value="2-4 năm">2-4 năm</SelectItem>
                            <SelectItem value="3-5 năm">3-5 năm</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Select value={salaryRange} onValueChange={setSalaryRange}>
                          <SelectTrigger>
                            <SelectValue placeholder="Mức lương" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Tất cả mức lương</SelectItem>
                            <SelectItem value="10-20">10-20 triệu</SelectItem>
                            <SelectItem value="20-30">20-30 triệu</SelectItem>
                            <SelectItem value="30-50">30-50 triệu</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Select value={selectedJobType} onValueChange={setSelectedJobType}>
                          <SelectTrigger>
                            <SelectValue placeholder="Loại hình" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Tất cả loại hình</SelectItem>
                            <SelectItem value="Full-time">Full-time</SelectItem>
                            <SelectItem value="Part-time">Part-time</SelectItem>
                            <SelectItem value="Remote">Remote</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {activeFiltersCount > 0 && (
                      <div className="flex justify-end mt-4">
                        <Button variant="ghost" size="sm" onClick={clearFilters}>
                          <X className="h-4 w-4 mr-2" />
                          Xóa bộ lọc
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="container mx-auto px-4 py-8">
          {/* Results Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h2 className="text-xl font-semibold">Tìm thấy {filteredJobs.length} việc làm</h2>
              {searchQuery && <p className="text-muted-foreground">Kết quả cho "{searchQuery}"</p>}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Sắp xếp:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Mới nhất</SelectItem>
                  <SelectItem value="salary-high">Lương cao nhất</SelectItem>
                  <SelectItem value="salary-low">Lương thấp nhất</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Job List */}
          <div className="space-y-4">
            {filteredJobs.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-muted-foreground mb-4">
                  <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Không tìm thấy việc làm phù hợp</p>
                  <p className="text-sm">Thử thay đổi từ khóa tìm kiếm hoặc bộ lọc</p>
                </div>
                <Button variant="outline" onClick={clearFilters}>
                  Xóa tất cả bộ lọc
                </Button>
              </div>
            ) : (
              filteredJobs.map((job) => (
                <Card key={job.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row gap-4">
                      <div className="flex items-start gap-4 flex-1">
                        <img
                          src={job.logo || "/placeholder.svg"}
                          alt={`${job.company} logo`}
                          className="w-16 h-16 rounded-lg object-cover"
                        />

                        <div className="flex-1">
                          <Link href={`/jobs/${job.id}`}>
                            <h3 className="text-lg font-semibold hover:text-primary transition-colors cursor-pointer">
                              {job.title}
                            </h3>
                          </Link>

                          <div className="flex items-center gap-1 text-muted-foreground mb-2">
                            <Building2 className="h-4 w-4" />
                            <span>{job.company}</span>
                          </div>

                          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-3">
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              <span>{job.location}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <DollarSign className="h-4 w-4" />
                              <span>{job.salary}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>{job.experience}</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {job.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col justify-between items-end gap-2">
                        <Badge variant="secondary" className="text-xs">
                          {job.type}
                        </Badge>

                        <div className="text-xs text-muted-foreground text-right">
                          <div>{job.posted}</div>
                        </div>

                        <Link href={`/jobs/${job.id}`}>
                          <Button size="sm" variant="outline" className="bg-transparent">
                            Xem chi tiết
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Pagination would go here */}
          {filteredJobs.length > 0 && (
            <div className="flex justify-center mt-8">
              <div className="flex gap-2">
                <Button variant="outline" disabled>
                  Trước
                </Button>
                <Button variant="default">1</Button>
                <Button variant="outline">2</Button>
                <Button variant="outline">3</Button>
                <Button variant="outline">Sau</Button>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
