"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Mail,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  GraduationCap,
  FileText,
  Settings,
  Edit,
  Download,
  Eye,
  Clock,
  Building2,
} from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

// Mock user data
const userData = {
  id: 1,
  name: "Nguyễn Văn A",
  email: "nguyenvana@email.com",
  phone: "0123456789",
  location: "TP. Hồ Chí Minh",
  avatar: "/professional-headshot.png",
  title: "Senior Frontend Developer",
  bio: "Tôi là một Frontend Developer với 5 năm kinh nghiệm trong việc phát triển ứng dụng web hiện đại. Đam mê công nghệ và luôn học hỏi những xu hướng mới.",
  skills: ["React", "TypeScript", "Next.js", "Tailwind CSS", "Node.js", "GraphQL"],
  experience: [
    {
      id: 1,
      company: "TechViet Solutions",
      position: "Senior Frontend Developer",
      duration: "2022 - Hiện tại",
      description: "Phát triển và duy trì các ứng dụng web frontend sử dụng React và TypeScript.",
    },
    {
      id: 2,
      company: "WebDev Studio",
      position: "Frontend Developer",
      duration: "2020 - 2022",
      description: "Xây dựng giao diện người dùng responsive và tối ưu hiệu suất website.",
    },
  ],
  education: [
    {
      id: 1,
      school: "Đại học Bách Khoa TP.HCM",
      degree: "Cử nhân Công nghệ Thông tin",
      duration: "2016 - 2020",
      gpa: "3.5/4.0",
    },
  ],
  applications: [
    {
      id: 1,
      jobTitle: "Senior React Developer",
      company: "ABC Tech",
      appliedDate: "2024-01-15",
      status: "pending",
    },
    {
      id: 2,
      jobTitle: "Frontend Lead",
      company: "XYZ Corp",
      appliedDate: "2024-01-10",
      status: "interview",
    },
    {
      id: 3,
      jobTitle: "Full Stack Developer",
      company: "StartupVN",
      appliedDate: "2024-01-05",
      status: "rejected",
    },
  ],
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "pending":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "interview":
      return "bg-blue-100 text-blue-800 border-blue-200"
    case "accepted":
      return "bg-green-100 text-green-800 border-green-200"
    case "rejected":
      return "bg-red-100 text-red-800 border-red-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getStatusText = (status: string) => {
  switch (status) {
    case "pending":
      return "Đang chờ"
    case "interview":
      return "Phỏng vấn"
    case "accepted":
      return "Được nhận"
    case "rejected":
      return "Từ chối"
    default:
      return status
  }
}

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/30">
        <div className="container mx-auto px-4 py-8">
          {/* Profile Header */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex flex-col items-center md:items-start">
                  <Avatar className="w-24 h-24 mb-4">
                    <AvatarImage src={userData.avatar || "/placeholder.svg"} alt={userData.name} />
                    <AvatarFallback className="text-lg">
                      {userData.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <Link href="/profile/edit">
                    <Button variant="outline" size="sm" className="bg-transparent">
                      <Edit className="h-4 w-4 mr-2" />
                      Chỉnh sửa
                    </Button>
                  </Link>
                </div>

                <div className="flex-1">
                  <div className="flex flex-col md:flex-row justify-between items-start mb-4">
                    <div>
                      <h1 className="text-2xl font-bold text-foreground mb-2">{userData.name}</h1>
                      <p className="text-lg text-primary font-medium mb-2">{userData.title}</p>
                      <p className="text-muted-foreground mb-4 max-w-2xl">{userData.bio}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <span>{userData.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <span>{userData.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{userData.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>Tham gia từ 2020</span>
                    </div>
                  </div>

                  <div className="mt-4">
                    <h3 className="font-medium mb-2">Kỹ năng</h3>
                    <div className="flex flex-wrap gap-2">
                      {userData.skills.map((skill) => (
                        <Badge key={skill} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Tổng quan</TabsTrigger>
              <TabsTrigger value="experience">Kinh nghiệm</TabsTrigger>
              <TabsTrigger value="applications">Ứng tuyển</TabsTrigger>
              <TabsTrigger value="settings">Cài đặt</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Experience Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Briefcase className="h-5 w-5" />
                      Kinh nghiệm làm việc
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {userData.experience.slice(0, 2).map((exp) => (
                      <div key={exp.id} className="space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{exp.position}</h4>
                            <p className="text-sm text-muted-foreground">{exp.company}</p>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {exp.duration}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{exp.description}</p>
                        {exp.id !== userData.experience.length && <Separator />}
                      </div>
                    ))}
                    <Link href="/profile/edit">
                      <Button variant="outline" size="sm" className="w-full bg-transparent">
                        Xem tất cả
                      </Button>
                    </Link>
                  </CardContent>
                </Card>

                {/* Education */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <GraduationCap className="h-5 w-5" />
                      Học vấn
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {userData.education.map((edu) => (
                      <div key={edu.id} className="space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{edu.degree}</h4>
                            <p className="text-sm text-muted-foreground">{edu.school}</p>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {edu.duration}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">GPA: {edu.gpa}</p>
                      </div>
                    ))}
                    <Link href="/profile/edit">
                      <Button variant="outline" size="sm" className="w-full bg-transparent">
                        Thêm học vấn
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </div>

              {/* CV Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    CV của tôi
                  </CardTitle>
                  <CardDescription>Quản lý và tải xuống CV của bạn</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <FileText className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">CV_NguyenVanA_2024.pdf</h4>
                        <p className="text-sm text-muted-foreground">Cập nhật lần cuối: 15/01/2024</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="bg-transparent">
                        <Eye className="h-4 w-4 mr-2" />
                        Xem
                      </Button>
                      <Button variant="outline" size="sm" className="bg-transparent">
                        <Download className="h-4 w-4 mr-2" />
                        Tải xuống
                      </Button>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Button variant="outline" className="bg-transparent">
                      <FileText className="h-4 w-4 mr-2" />
                      Tải CV mới
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Experience Tab */}
            <TabsContent value="experience" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Kinh nghiệm làm việc</CardTitle>
                    <Link href="/profile/edit">
                      <Button variant="outline" size="sm" className="bg-transparent">
                        <Edit className="h-4 w-4 mr-2" />
                        Chỉnh sửa
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {userData.experience.map((exp, index) => (
                    <div key={exp.id}>
                      <div className="flex gap-4">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Briefcase className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-semibold">{exp.position}</h3>
                              <p className="text-muted-foreground">{exp.company}</p>
                            </div>
                            <Badge variant="outline">{exp.duration}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{exp.description}</p>
                        </div>
                      </div>
                      {index < userData.experience.length - 1 && <Separator className="mt-6" />}
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Học vấn</CardTitle>
                    <Link href="/profile/edit">
                      <Button variant="outline" size="sm" className="bg-transparent">
                        <Edit className="h-4 w-4 mr-2" />
                        Chỉnh sửa
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {userData.education.map((edu) => (
                    <div key={edu.id} className="flex gap-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <GraduationCap className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-semibold">{edu.degree}</h3>
                            <p className="text-muted-foreground">{edu.school}</p>
                          </div>
                          <Badge variant="outline">{edu.duration}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">GPA: {edu.gpa}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Applications Tab */}
            <TabsContent value="applications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Lịch sử ứng tuyển</CardTitle>
                  <CardDescription>Theo dõi trạng thái các đơn ứng tuyển của bạn</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userData.applications.map((app) => (
                      <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                            <Building2 className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium">{app.jobTitle}</h4>
                            <p className="text-sm text-muted-foreground">{app.company}</p>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                              <Clock className="h-3 w-3" />
                              <span>Ứng tuyển ngày {app.appliedDate}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge className={getStatusColor(app.status)}>{getStatusText(app.status)}</Badge>
                          <Button variant="outline" size="sm" className="bg-transparent">
                            Chi tiết
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Cài đặt tài khoản
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Thông báo email</h4>
                      <p className="text-sm text-muted-foreground">Nhận thông báo về việc làm mới và cập nhật</p>
                    </div>
                    <Button variant="outline" size="sm" className="bg-transparent">
                      Cài đặt
                    </Button>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Quyền riêng tư</h4>
                      <p className="text-sm text-muted-foreground">Quản lý ai có thể xem hồ sơ của bạn</p>
                    </div>
                    <Button variant="outline" size="sm" className="bg-transparent">
                      Cài đặt
                    </Button>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Đổi mật khẩu</h4>
                      <p className="text-sm text-muted-foreground">Cập nhật mật khẩu để bảo mật tài khoản</p>
                    </div>
                    <Button variant="outline" size="sm" className="bg-transparent">
                      Đổi mật khẩu
                    </Button>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-destructive">Xóa tài khoản</h4>
                      <p className="text-sm text-muted-foreground">Xóa vĩnh viễn tài khoản và tất cả dữ liệu</p>
                    </div>
                    <Button variant="destructive" size="sm">
                      Xóa tài khoản
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
