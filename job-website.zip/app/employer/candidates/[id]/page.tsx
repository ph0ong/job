"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  Award,
  Download,
  MessageSquare,
  ArrowLeft,
  Star,
} from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useParams } from "next/navigation"

// Mock candidate data
const candidateData = {
  id: 1,
  name: "Nguyễn Văn A",
  email: "nguyenvana@email.com",
  phone: "0123456789",
  location: "TP. Hồ Chí Minh",
  avatar: "/professional-headshot.png",
  appliedJob: "Senior Frontend Developer",
  appliedDate: "2024-01-16",
  status: "pending",
  experience: "5 năm",
  expectedSalary: "25-30 triệu",
  summary:
    "Tôi là một Frontend Developer với 5 năm kinh nghiệm trong việc phát triển ứng dụng web hiện đại. Có kinh nghiệm làm việc với React, TypeScript, và Next.js. Đam mê tạo ra những giao diện người dùng đẹp và hiệu quả.",
  skills: ["React", "TypeScript", "Next.js", "JavaScript", "HTML/CSS", "Node.js", "Git", "Figma"],
  workExperience: [
    {
      company: "Tech Solutions Co.",
      position: "Senior Frontend Developer",
      duration: "2022 - Hiện tại",
      description:
        "Phát triển và duy trì các ứng dụng web sử dụng React và TypeScript. Làm việc với team backend để tích hợp API. Tối ưu hiệu suất ứng dụng và trải nghiệm người dùng.",
    },
    {
      company: "Digital Agency",
      position: "Frontend Developer",
      duration: "2020 - 2022",
      description:
        "Xây dựng website và ứng dụng web cho khách hàng. Sử dụng HTML, CSS, JavaScript và React. Hợp tác với designer để implement UI/UX.",
    },
  ],
  education: [
    {
      school: "Đại học Bách Khoa TP.HCM",
      degree: "Cử nhân Công nghệ Thông tin",
      duration: "2016 - 2020",
      gpa: "3.5/4.0",
    },
  ],
  projects: [
    {
      name: "E-commerce Platform",
      description: "Xây dựng platform thương mại điện tử sử dụng Next.js, TypeScript và Stripe",
      technologies: ["Next.js", "TypeScript", "Stripe", "Tailwind CSS"],
    },
    {
      name: "Task Management App",
      description: "Ứng dụng quản lý công việc với real-time updates sử dụng Socket.io",
      technologies: ["React", "Node.js", "Socket.io", "MongoDB"],
    },
  ],
}

export default function CandidateDetail() {
  const params = useParams()
  const [status, setStatus] = useState(candidateData.status)
  const [notes, setNotes] = useState("")
  const [rating, setRating] = useState(0)

  const handleStatusChange = (newStatus: string) => {
    setStatus(newStatus)
    // TODO: Update status in backend
  }

  const handleSaveNotes = () => {
    // TODO: Save notes to backend
    console.log("Saving notes:", notes)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "interview":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "accepted":
        return "bg-green-100 text-green-800 border-green-200"
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "Đang chờ"
      case "interview":
        return "Phỏng vấn"
      case "accepted":
        return "Được nhận"
      case "rejected":
        return "Từ chối"
      default:
        return status
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/30">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Link href="/employer/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Quay lại
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">Hồ sơ ứng viên</h1>
              <p className="text-muted-foreground">Chi tiết thông tin ứng viên</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Candidate Info */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Info */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                        <User className="h-8 w-8 text-primary" />
                      </div>
                      <div>
                        <h2 className="text-xl font-bold">{candidateData.name}</h2>
                        <p className="text-muted-foreground">Ứng tuyển: {candidateData.appliedJob}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mt-2">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>Ứng tuyển: {candidateData.appliedDate}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Briefcase className="h-3 w-3" />
                            <span>Kinh nghiệm: {candidateData.experience}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <Badge className={getStatusColor(status)}>{getStatusText(status)}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{candidateData.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{candidateData.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{candidateData.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-muted-foreground" />
                      <span>Mong muốn: {candidateData.expectedSalary}</span>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Giới thiệu bản thân</h3>
                    <p className="text-muted-foreground">{candidateData.summary}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Skills */}
              <Card>
                <CardHeader>
                  <CardTitle>Kỹ năng</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {candidateData.skills.map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Work Experience */}
              <Card>
                <CardHeader>
                  <CardTitle>Kinh nghiệm làm việc</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {candidateData.workExperience.map((exp, index) => (
                      <div key={index} className="border-l-2 border-primary/20 pl-4">
                        <h3 className="font-semibold">{exp.position}</h3>
                        <p className="text-primary font-medium">{exp.company}</p>
                        <p className="text-sm text-muted-foreground mb-2">{exp.duration}</p>
                        <p className="text-sm">{exp.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Education */}
              <Card>
                <CardHeader>
                  <CardTitle>Học vấn</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {candidateData.education.map((edu, index) => (
                      <div key={index} className="border-l-2 border-primary/20 pl-4">
                        <h3 className="font-semibold">{edu.degree}</h3>
                        <p className="text-primary font-medium">{edu.school}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{edu.duration}</span>
                          <span>GPA: {edu.gpa}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Projects */}
              <Card>
                <CardHeader>
                  <CardTitle>Dự án nổi bật</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {candidateData.projects.map((project, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <h3 className="font-semibold mb-2">{project.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{project.description}</p>
                        <div className="flex flex-wrap gap-1">
                          {project.technologies.map((tech) => (
                            <Badge key={tech} variant="outline" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Actions */}
            <div className="space-y-6">
              {/* Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Hành động</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Tải CV
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Gửi tin nhắn
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Mail className="h-4 w-4 mr-2" />
                    Gửi email
                  </Button>
                </CardContent>
              </Card>

              {/* Status Management */}
              <Card>
                <CardHeader>
                  <CardTitle>Quản lý trạng thái</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Trạng thái ứng tuyển</label>
                    <Select value={status} onValueChange={handleStatusChange}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Đang chờ</SelectItem>
                        <SelectItem value="interview">Phỏng vấn</SelectItem>
                        <SelectItem value="accepted">Được nhận</SelectItem>
                        <SelectItem value="rejected">Từ chối</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Đánh giá</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setRating(star)}
                          className={`p-1 ${star <= rating ? "text-yellow-400" : "text-gray-300"}`}
                        >
                          <Star className="h-4 w-4 fill-current" />
                        </button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Notes */}
              <Card>
                <CardHeader>
                  <CardTitle>Ghi chú</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Thêm ghi chú về ứng viên..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={4}
                  />
                  <Button onClick={handleSaveNotes} className="w-full">
                    Lưu ghi chú
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
