"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Building2,
  Plus,
  Search,
  Eye,
  Edit,
  Trash2,
  Users,
  Clock,
  MapPin,
  DollarSign,
  BarChart3,
  FileText,
} from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

// Mock data
const jobPosts = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    location: "TP. Hồ Chí Minh",
    salary: "25-35 triệu",
    status: "active",
    applications: 24,
    views: 156,
    postedDate: "2024-01-15",
    deadline: "2024-02-15",
  },
  {
    id: 2,
    title: "Marketing Manager",
    location: "Hà Nội",
    salary: "20-30 triệu",
    status: "paused",
    applications: 18,
    views: 89,
    postedDate: "2024-01-10",
    deadline: "2024-02-10",
  },
  {
    id: 3,
    title: "UX/UI Designer",
    location: "Đà Nẵng",
    salary: "15-25 triệu",
    status: "expired",
    applications: 12,
    views: 67,
    postedDate: "2023-12-20",
    deadline: "2024-01-20",
  },
]

const applications = [
  {
    id: 1,
    candidateName: "Nguyễn Văn A",
    jobTitle: "Senior Frontend Developer",
    appliedDate: "2024-01-16",
    status: "pending",
    experience: "5 năm",
    skills: ["React", "TypeScript", "Next.js"],
  },
  {
    id: 2,
    candidateName: "Trần Thị B",
    jobTitle: "Marketing Manager",
    appliedDate: "2024-01-14",
    status: "interview",
    experience: "3 năm",
    skills: ["Digital Marketing", "SEO", "Analytics"],
  },
  {
    id: 3,
    candidateName: "Lê Văn C",
    jobTitle: "UX/UI Designer",
    appliedDate: "2024-01-12",
    status: "rejected",
    experience: "2 năm",
    skills: ["Figma", "Adobe XD", "Prototyping"],
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "active":
      return "bg-green-100 text-green-800 border-green-200"
    case "paused":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "expired":
      return "bg-red-100 text-red-800 border-red-200"
    case "pending":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "interview":
      return "bg-blue-100 text-blue-800 border-blue-200"
    case "accepted":
      return "bg-green-100 text-green-800 border-green-200"
    case "rejected":
      return "bg-red-100 text-red-800 border-red-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getStatusText = (status: string) => {
  switch (status) {
    case "active":
      return "Đang tuyển"
    case "paused":
      return "Tạm dừng"
    case "expired":
      return "Hết hạn"
    case "pending":
      return "Đang chờ"
    case "interview":
      return "Phỏng vấn"
    case "accepted":
      return "Được nhận"
    case "rejected":
      return "Từ chối"
    default:
      return status
  }
}

export default function EmployerDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("jobs")

  const filteredJobs = jobPosts.filter((job) => job.title.toLowerCase().includes(searchQuery.toLowerCase()))

  const totalApplications = jobPosts.reduce((sum, job) => sum + job.applications, 0)
  const totalViews = jobPosts.reduce((sum, job) => sum + job.views, 0)
  const activeJobs = jobPosts.filter((job) => job.status === "active").length

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 bg-muted/30">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className="text-2xl font-bold">Dashboard Nhà tuyển dụng</h1>
              <p className="text-muted-foreground">Quản lý tin đăng và ứng viên của bạn</p>
            </div>
            <Link href="/post-job">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Đăng tin mới
              </Button>
            </Link>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Tin đăng</p>
                    <p className="text-2xl font-bold">{jobPosts.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Users className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Ứng viên</p>
                    <p className="text-2xl font-bold">{totalApplications}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Eye className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Lượt xem</p>
                    <p className="text-2xl font-bold">{totalViews}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <BarChart3 className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Đang tuyển</p>
                    <p className="text-2xl font-bold">{activeJobs}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="jobs">Tin đăng của tôi</TabsTrigger>
              <TabsTrigger value="applications">Ứng viên</TabsTrigger>
            </TabsList>

            {/* Jobs Tab */}
            <TabsContent value="jobs" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Quản lý tin đăng</CardTitle>
                    <div className="flex gap-2">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Tìm kiếm tin đăng..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10 w-64"
                        />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {filteredJobs.map((job) => (
                      <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <Building2 className="h-6 w-6 text-primary" />
                          </div>

                          <div className="flex-1">
                            <h3 className="font-semibold">{job.title}</h3>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                              <div className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                <span>{job.location}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <DollarSign className="h-3 w-3" />
                                <span>{job.salary}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                <span>Đăng {job.postedDate}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-6 text-sm">
                            <div className="text-center">
                              <div className="font-semibold">{job.applications}</div>
                              <div className="text-muted-foreground">Ứng viên</div>
                            </div>
                            <div className="text-center">
                              <div className="font-semibold">{job.views}</div>
                              <div className="text-muted-foreground">Lượt xem</div>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <Badge className={getStatusColor(job.status)}>{getStatusText(job.status)}</Badge>

                          <div className="flex gap-1">
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Applications Tab */}
            <TabsContent value="applications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Ứng viên mới nhất</CardTitle>
                  <CardDescription>Quản lý và đánh giá các ứng viên</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {applications.map((app) => (
                      <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <Users className="h-6 w-6 text-primary" />
                          </div>

                          <div className="flex-1">
                            <h3 className="font-semibold">{app.candidateName}</h3>
                            <p className="text-sm text-muted-foreground">{app.jobTitle}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1">
                              <span>Ứng tuyển: {app.appliedDate}</span>
                              <span>Kinh nghiệm: {app.experience}</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-1">
                            {app.skills.slice(0, 3).map((skill) => (
                              <Badge key={skill} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <Badge className={getStatusColor(app.status)}>{getStatusText(app.status)}</Badge>

                          <div className="flex gap-1">
                            <Button variant="outline" size="sm" className="bg-transparent" asChild>
                              <Link href={`/employer/candidates/${app.id}`}>Xem CV</Link>
                            </Button>
                            <Button size="sm">Liên hệ</Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
