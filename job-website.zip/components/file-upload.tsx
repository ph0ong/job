"use client"

import { useCallback, useState } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, type File, X, CheckCircle } from "lucide-react"
import { toast } from "sonner"

interface FileUploadProps {
  onFileSelect: (file: File) => void
  acceptedTypes?: string[]
  maxSize?: number // in MB
  className?: string
}

export function FileUpload({
  onFileSelect,
  acceptedTypes = [".pdf", ".doc", ".docx"],
  maxSize = 5,
  className = "",
}: FileUploadProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const file = acceptedFiles[0]
      if (!file) return

      if (file.size > maxSize * 1024 * 1024) {
        toast.error(`File không được vượt quá ${maxSize}MB`)
        return
      }

      const fileExtension = "." + file.name.split(".").pop()?.toLowerCase()
      if (!acceptedTypes.includes(fileExtension)) {
        toast.error(`Chỉ chấp nhận file: ${acceptedTypes.join(", ")}`)
        return
      }

      setIsUploading(true)

      try {
        // Simulate upload delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setUploadedFile(file)
        onFileSelect(file)
        toast.success("Tải file thành công!")
      } catch (error) {
        toast.error("Có lỗi khi tải file")
      } finally {
        setIsUploading(false)
      }
    },
    [acceptedTypes, maxSize, onFileSelect],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: acceptedTypes.reduce(
      (acc, type) => {
        acc[type] = []
        return acc
      },
      {} as Record<string, string[]>,
    ),
    maxFiles: 1,
    disabled: isUploading,
  })

  const removeFile = () => {
    setUploadedFile(null)
  }

  if (uploadedFile) {
    return (
      <Card className={className}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-sm">{uploadedFile.name}</p>
                <p className="text-xs text-gray-500">{(uploadedFile.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={removeFile} className="text-red-600 hover:text-red-700">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={className}>
      <CardContent className="p-6">
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
            isDragActive ? "border-blue-400 bg-blue-50" : "border-gray-300 hover:border-gray-400"
          } ${isUploading ? "opacity-50 cursor-not-allowed" : ""}`}
        >
          <input {...getInputProps()} />
          <Upload className="w-8 h-8 mx-auto mb-4 text-gray-400" />
          {isUploading ? (
            <p className="text-sm text-gray-600">Đang tải file...</p>
          ) : isDragActive ? (
            <p className="text-sm text-blue-600">Thả file vào đây...</p>
          ) : (
            <div>
              <p className="text-sm text-gray-600 mb-2">Kéo thả file vào đây hoặc click để chọn</p>
              <p className="text-xs text-gray-500">
                Chấp nhận: {acceptedTypes.join(", ")} (tối đa {maxSize}MB)
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
