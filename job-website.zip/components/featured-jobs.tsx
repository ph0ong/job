import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, DollarSign, Building2 } from "lucide-react"
import Link from "next/link"

const featuredJobs = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechViet Solutions",
    location: "TP. Hồ Chí Minh",
    salary: "25-35 triệu",
    type: "Full-time",
    logo: "/abstract-tech-logo.png",
    tags: ["React", "TypeScript", "Next.js"],
    posted: "2 ngày trước",
  },
  {
    id: 2,
    title: "Marketing Manager",
    company: "Digital Marketing Pro",
    location: "Hà Nội",
    salary: "20-30 triệu",
    type: "Full-time",
    logo: "/marketing-company-logo.png",
    tags: ["Digital Marketing", "SEO", "Social Media"],
    posted: "1 ngày trước",
  },
  {
    id: 3,
    title: "UX/UI Designer",
    company: "Creative Studio",
    location: "Đà Nẵng",
    salary: "15-25 triệu",
    type: "Full-time",
    logo: "/design-studio-logo.png",
    tags: ["Figma", "Adobe XD", "Prototyping"],
    posted: "3 ngày trước",
  },
  {
    id: 4,
    title: "Data Analyst",
    company: "Analytics Corp",
    location: "TP. Hồ Chí Minh",
    salary: "18-28 triệu",
    type: "Full-time",
    logo: "/analytics-company-logo.png",
    tags: ["Python", "SQL", "Tableau"],
    posted: "1 ngày trước",
  },
  {
    id: 5,
    title: "Product Manager",
    company: "StartupVN",
    location: "Hà Nội",
    salary: "30-45 triệu",
    type: "Full-time",
    logo: "/startup-logo.png",
    tags: ["Product Strategy", "Agile", "Analytics"],
    posted: "4 ngày trước",
  },
  {
    id: 6,
    title: "DevOps Engineer",
    company: "CloudTech Vietnam",
    location: "TP. Hồ Chí Minh",
    salary: "25-40 triệu",
    type: "Full-time",
    logo: "/cloud-tech-logo.png",
    tags: ["AWS", "Docker", "Kubernetes"],
    posted: "2 ngày trước",
  },
]

export function FeaturedJobs() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Việc làm nổi bật</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Khám phá những cơ hội việc làm hấp dẫn từ các công ty hàng đầu
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {featuredJobs.map((job) => (
            <Card key={job.id} className="hover:shadow-lg transition-shadow cursor-pointer group">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={job.logo || "/placeholder.svg"}
                      alt={`${job.company} logo`}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div>
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">{job.title}</CardTitle>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Building2 className="h-4 w-4" />
                        <span className="text-sm">{job.company}</span>
                      </div>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {job.type}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{job.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <DollarSign className="h-4 w-4" />
                    <span>{job.salary}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {job.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{job.posted}</span>
                  </div>
                  <Link href={`/jobs/${job.id}`}>
                    <Button
                      size="sm"
                      variant="outline"
                      className="group-hover:bg-primary group-hover:text-primary-foreground transition-colors bg-transparent"
                    >
                      Xem chi tiết
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link href="/jobs">
            <Button size="lg" variant="outline">
              Xem tất cả việc làm
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
