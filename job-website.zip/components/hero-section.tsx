"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin } from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("")
  const [location, setLocation] = useState("")
  const router = useRouter()

  const handleSearch = () => {
    const params = new URLSearchParams()
    if (searchQuery) params.set("q", searchQuery)
    if (location) params.set("location", location)

    router.push(`/jobs?${params.toString()}`)
  }

  return (
    <section className="relative bg-gradient-to-br from-primary/5 via-background to-accent/5 py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Hero Content */}
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Tìm việc làm <span className="text-primary">mơ ước</span> của bạn
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Khám phá hàng nghìn cơ hội việc làm từ các công ty hàng đầu Việt Nam. Kết nối với nhà tuyển dụng và xây dựng
            sự nghiệp của bạn.
          </p>

          {/* Search Form */}
          <div className="bg-card rounded-xl p-6 shadow-lg border max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Job Title/Keywords */}
              <div className="md:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Vị trí, từ khóa..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12"
                    onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                  />
                </div>
              </div>

              {/* Location */}
              <div>
                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger className="h-12">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <SelectValue placeholder="Địa điểm" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ho-chi-minh">TP. Hồ Chí Minh</SelectItem>
                    <SelectItem value="ha-noi">Hà Nội</SelectItem>
                    <SelectItem value="da-nang">Đà Nẵng</SelectItem>
                    <SelectItem value="hai-phong">Hải Phòng</SelectItem>
                    <SelectItem value="can-tho">Cần Thơ</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Search Button */}
              <div>
                <Button className="w-full h-12 text-base font-medium" onClick={handleSearch}>
                  <Search className="h-4 w-4 mr-2" />
                  Tìm kiếm
                </Button>
              </div>
            </div>

            {/* Quick Categories */}
            <div className="flex flex-wrap gap-2 mt-6 pt-6 border-t">
              <span className="text-sm text-muted-foreground mr-2">Danh mục phổ biến:</span>
              {["IT - Phần mềm", "Marketing", "Kế toán", "Nhân sự", "Bán hàng"].map((cat) => (
                <Button
                  key={cat}
                  variant="outline"
                  size="sm"
                  className="text-xs bg-transparent"
                  onClick={() => {
                    setSearchQuery(cat)
                    handleSearch()
                  }}
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">50K+</div>
              <div className="text-sm text-muted-foreground">Việc làm</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">10K+</div>
              <div className="text-sm text-muted-foreground">Công ty</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">1M+</div>
              <div className="text-sm text-muted-foreground">Ứng viên</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">95%</div>
              <div className="text-sm text-muted-foreground">Thành công</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
